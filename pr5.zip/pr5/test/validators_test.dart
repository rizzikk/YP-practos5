import 'package:flutter_test/flutter_test.dart';
import 'package:library_client/forms/validators.dart';

void main() {
  test('обязательность и длина', () {
    final v = Validators.all([Validators.required(), Validators.length(min: 2, max: 5)]);
    expect(v(''), 'Обязательное поле');
    expect(v('а'), 'Не короче 2 символов');
    expect(v('абвгдеж'), 'Не длиннее 5 символов');
    expect(v('абв'), isNull);
  });

  test('числа: диапазон и положительность', () {
    expect(Validators.intRange(1, 10)('0'), 'Допустимо от 1 до 10');
    expect(Validators.intRange(1, 10)('abc'), 'Введите целое число');
    expect(Validators.positive()('0'), 'Должно быть больше нуля');
    expect(Validators.positive()('3'), isNull);
  });

  test('почта, телефон, ISBN, номер билета', () {
    expect(Validators.email()('ivan@mail.ru'), isNull);
    expect(Validators.email()('ivan@mail'), isNotNull);
    expect(Validators.phone()('+7 (916) 123-45-67'), isNull);
    expect(Validators.phone()('12345'), 'От 10 до 15 цифр');
    expect(Validators.isbn()('978-5-17-090101-1'), isNull);
    expect(Validators.isbn()('123-4'), isNotNull);
    expect(Validators.cardNumber()('ЧБ-000123'), isNull);
    expect(Validators.cardNumber()('ЧБ123'), isNotNull);
  });

  test('даты', () {
    expect(parseDate('29.02.2024'), DateTime(2024, 2, 29));
    expect(parseDate('31.02.2024'), isNull);
    expect(Validators.date(notAfter: DateTime(2026))('02.01.2026'), 'Не позже 01.01.2026');
    expect(formatDate(DateTime(2026, 3, 7)), '07.03.2026');
  });
}
