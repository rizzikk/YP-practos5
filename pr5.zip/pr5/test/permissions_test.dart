import 'package:flutter_test/flutter_test.dart';
import 'package:library_client/auth/permissions.dart';

/// Логика разграничения прав: какой роли какая операция доступна.
/// Таблица совпадает с таблицей прав в отчёте.
void main() {
  const r = Role.reader, l = Role.librarian, a = Role.admin;

  // (роль, операция, доступна ли)
  const matrix = <(Role, Permission, bool)>[
    // каталог видят все
    (r, Permission.viewCatalog, true),
    (l, Permission.viewCatalog, true),
    (a, Permission.viewCatalog, true),
    // изменять каталог и справочники — сотрудники
    (r, Permission.editCatalog, false),
    (l, Permission.editCatalog, true),
    (a, Permission.editCatalog, true),
    // свои выдачи и продление — читатель
    (r, Permission.viewOwnLoans, true),
    (r, Permission.extendOwnLoan, true),
    (l, Permission.viewOwnLoans, false),
    // оформление и закрытие выдач — библиотекарь
    (r, Permission.manageLoans, false),
    (l, Permission.manageLoans, true),
    (a, Permission.manageLoans, false),
    // читатели — сотрудники
    (r, Permission.manageReaders, false),
    (l, Permission.manageReaders, true),
    // физическое удаление и восстановление — администратор
    (r, Permission.hardDelete, false),
    (l, Permission.hardDelete, false),
    (a, Permission.hardDelete, true),
    (l, Permission.restore, false),
    (a, Permission.restore, true),
    (l, Permission.viewDeleted, false),
    (a, Permission.viewDeleted, true),
    // пользователи и статистика — администратор
    (r, Permission.manageUsers, false),
    (l, Permission.manageUsers, false),
    (a, Permission.manageUsers, true),
    (l, Permission.viewStats, false),
    (a, Permission.viewStats, true),
  ];

  for (final (role, permission, expected) in matrix) {
    test('${role.name}: ${permission.name} → ${expected ? 'да' : 'нет'}', () {
      expect(can(role, permission), expected);
    });
  }

  test('без входа нет ни одного права', () {
    for (final p in Permission.values) {
      expect(can(null, p), isFalse, reason: p.name);
    }
  });

  test('у каждой роли есть право, которого нет у других', () {
    for (final role in Role.values) {
      final others = {
        for (final other in Role.values)
          if (other != role) ...rolePermissions[other]!,
      };
      final own = rolePermissions[role]!.difference(others);
      expect(own, isNotEmpty, reason: role.name);
    }
  });

  test('роли различаются составом функций, а не вложены друг в друга', () {
    final reader = rolePermissions[r]!;
    final librarian = rolePermissions[l]!;
    final admin = rolePermissions[a]!;
    expect(librarian.containsAll(reader), isFalse);
    expect(admin.containsAll(librarian), isFalse);
  });

  test('неизвестная роль с сервера — самая слабая', () {
    expect(Role.parse('admin'), Role.admin);
    expect(Role.parse('librarian'), Role.librarian);
    expect(Role.parse('superuser'), Role.reader);
    expect(Role.parse(null), Role.reader);
  });
}
