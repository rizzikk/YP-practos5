import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:library_client/core/api_client.dart';
import 'package:library_client/core/api_exceptions.dart';
import 'package:library_client/core/session.dart';
import 'package:library_client/models/book.dart';
import 'package:library_client/models/book_query.dart';
import 'package:library_client/models/list_query.dart';
import 'package:library_client/repositories/api_repositories.dart';
import 'package:library_client/repositories/loan_repository.dart';

import 'support/fake_adapter.dart';

Dio fakeDio(FakeAdapter adapter) {
  final dio = buildDio(ApiSession(),
      baseUrl: 'http://test/api',
      retryDelay: const Duration(milliseconds: 5),
      log: (_) {});
  dio.httpClientAdapter = adapter;
  return dio;
}

final bookJson = {
  'id': 1,
  'title': 'Война и мир',
  'isbn': '978-5-17-118366-4',
  'year': 1869,
  'pages': 1300,
  'publisher': {'id': 1, 'name': 'АСТ'},
  'authors': [
    {'id': 1, 'fullName': 'Толстой Л. Н.'}
  ],
  'genres': [
    {'id': 2, 'name': 'Роман'},
    {'id': 5, 'name': 'Классика'}
  ],
  'copiesTotal': 4,
  'copiesAvailable': 2,
  'deletedAt': null,
};

void main() {
  test('список: параметры уходят на сервер, ответ разбирается', () async {
    final adapter = FakeAdapter((o) => jsonBody(200, {
          'items': [bookJson],
          'page': 2,
          'size': 10,
          'total': 11,
          'totalPages': 2,
        }));
    final repo = ApiBookRepository(fakeDio(adapter));

    final page = await repo.find(const BookQuery(
        search: 'война', genreId: 2, sortField: 'year', sortAscending: false, page: 2));

    final q = adapter.requests.single.uri.queryParameters;
    expect(adapter.requests.single.uri.path, '/api/books');
    expect(q['search'], 'война');
    expect(q['genreId'], '2');
    expect(q['sort'], 'year,desc');
    expect(q['page'], '2');
    expect(page.total, 11);
    final book = page.items.single;
    expect(book.publisherId, 1);
    expect(book.authorIds, [1]);
    expect(book.genreIds, [2, 5]);
  });

  test('Book.fromJson понимает и форму записи, и форму чтения', () {
    final write = Book.fromJson(
        {'id': 3, 'publisherId': 4, 'authorIds': [7], 'genreIds': [1, 2]});
    final read = Book.fromJson(bookJson);
    expect(write.publisherId, 4);
    expect(write.authorIds, [7]);
    expect(read.publisherId, 1);
    expect(read.genreIds, [2, 5]);
    // на запись уходят идентификаторы, а не объекты
    expect(read.toInput()['publisherId'], 1);
    expect(read.toInput().containsKey('publisher'), isFalse);
  });

  test('422 → ValidationException с ошибками по полям', () async {
    final adapter = FakeAdapter((o) => jsonBody(422, {
          'message': 'Ошибка валидации',
          'errors': {'isbn': 'Книга с таким ISBN уже существует'},
        }));
    final repo = ApiBookRepository(fakeDio(adapter));
    final book = Book.fromJson(bookJson);

    await expectLater(
      repo.create(book),
      throwsA(isA<ValidationException>().having(
          (e) => e.errors['isbn'], 'errors[isbn]', 'Книга с таким ISBN уже существует')),
    );
  });

  test('409 → ConflictException с текстом сервера', () async {
    final adapter = FakeAdapter(
        (o) => jsonBody(409, {'message': 'Нет свободных экземпляров этой книги'}));
    final repo = ApiLoanRepository(fakeDio(adapter));

    await expectLater(
      repo.issue(readerId: 1, bookId: 20),
      throwsA(isA<ConflictException>()
          .having((e) => e.message, 'message', 'Нет свободных экземпляров этой книги')),
    );
  });

  test('сервер недоступен: чтение повторяется 3 раза, затем NetworkException',
      () async {
    final adapter = FakeAdapter((o) => throw DioException(
        requestOptions: o, type: DioExceptionType.connectionError));
    final repo = ApiGenreRepository(fakeDio(adapter));

    await expectLater(
      repo.find(const ListQuery(defaultSort: 'name')),
      throwsA(isA<NetworkException>()),
    );
    expect(adapter.requests, hasLength(3));
  });

  test('создание при сетевом сбое не повторяется', () async {
    final adapter = FakeAdapter((o) => throw DioException(
        requestOptions: o, type: DioExceptionType.connectionError));
    final repo = ApiBookRepository(fakeDio(adapter));

    await expectLater(
        repo.create(Book.fromJson(bookJson)), throwsA(isA<NetworkException>()));
    expect(adapter.requests, hasLength(1));
  });

  test('500 → ServerException, 404 по id → null', () async {
    final adapter = FakeAdapter((o) => o.path.endsWith('/7')
        ? jsonBody(404, {'message': 'Объект не найден'})
        : jsonBody(500, {'message': 'Сбой'}));
    final repo = ApiBookRepository(fakeDio(adapter));

    expect(await repo.findById(7), isNull);
    await expectLater(
        repo.find(const BookQuery()), throwsA(isA<ServerException>()));
  });

  test('новый запрос списка отменяет предыдущий', () async {
    final adapter = FakeAdapter((o) async {
      await Future<void>.delayed(const Duration(milliseconds: 50));
      return jsonBody(200, {'items': [], 'page': 1, 'size': 10, 'total': 0});
    });
    final repo = ApiBookRepository(fakeDio(adapter));

    final first = repo.find(const BookQuery(search: 'в'));
    final second = repo.find(const BookQuery(search: 'война'));

    await expectLater(first, throwsA(isA<CancelledException>()));
    expect((await second).total, 0);
  });

  test('свои выдачи запрашиваются с явным номером читателя', () async {
    final adapter = FakeAdapter((o) => jsonBody(200, {
          'items': [],
          'page': 1,
          'size': 25,
          'total': 0,
        }));
    final repo = ApiLoanRepository(fakeDio(adapter));

    await repo.find(const LoanQuery(readerId: 1, status: 'active'));

    final q = adapter.requests.single.uri.queryParameters;
    expect(adapter.requests.single.uri.path, '/api/loans');
    expect(q['readerId'], '1');
    expect(q['status'], 'active');
  });

  test('mapHttpError раскладывает коды по исключениям', () {
    expect(mapHttpError(401, null), isA<UnauthorizedException>());
    expect(mapHttpError(403, null), isA<ForbiddenException>());
    expect(mapHttpError(404, null), isA<NotFoundException>());
    expect(mapHttpError(409, {'message': 'x'}).message, 'x');
    expect(mapHttpError(503, null), isA<ServerException>());
  });
}
