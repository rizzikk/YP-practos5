import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:library_client/auth/auth_api.dart';
import 'package:library_client/auth/auth_notifier.dart';
import 'package:library_client/auth/permissions.dart';
import 'package:library_client/core/api_client.dart';
import 'package:library_client/core/api_exceptions.dart';
import 'package:library_client/core/config.dart';
import 'package:library_client/core/session.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'support/fake_adapter.dart';

/// Учебный сервер в миниатюре: вход, обновление токена и один защищённый
/// адрес. Роль берётся с «сервера», а не из запроса клиента.
class FakeServer {
  final validAccess = <String>{};
  final validRefresh = <String>{};
  int _issued = 0;
  bool refreshBroken = false;

  Map<String, dynamic> _tokens() {
    _issued++;
    final access = 'access-$_issued';
    final refresh = 'refresh-$_issued';
    validAccess.add(access);
    validRefresh.add(refresh);
    return {
      'accessToken': access,
      'refreshToken': refresh,
      'expiresIn': 60,
      'user': {
        'id': 3,
        'username': 'reader',
        'fullName': 'Смирнов П. А.',
        'role': 'reader',
        'readerId': 1,
      },
    };
  }

  ResponseBody handle(RequestOptions o) {
    final body = o.data is Map ? o.data as Map : const {};
    switch (o.uri.path) {
      case '/api/auth/login':
        return body['username'] == 'reader' && body['password'] == 'reader123'
            ? jsonBody(200, _tokens())
            : jsonBody(401, {'message': 'Неверный логин или пароль'});
      case '/api/auth/refresh':
        if (refreshBroken || !validRefresh.remove(body['refreshToken'])) {
          return jsonBody(401, {'message': 'Токен обновления недействителен'});
        }
        return jsonBody(200, _tokens());
      case '/api/auth/logout':
        validRefresh.remove(body['refreshToken']);
        return jsonBody(200, {});
    }
    final header = o.headers['Authorization'];
    if (header is! String || !validAccess.contains(header.substring(7))) {
      return jsonBody(401, {'message': 'Требуется аутентификация'});
    }
    return jsonBody(200, {'items': [], 'page': 1, 'size': 10, 'total': 0});
  }

  /// Срок всех выданных токенов доступа истёк.
  void expireAccess() => validAccess.clear();
}

void main() {
  late FakeServer server;
  late FakeAdapter adapter;
  late ApiSession session;
  late Dio dio;
  late SharedPreferences prefs;
  var now = DateTime(2026, 10, 29, 12);

  AuthNotifier newAuth() => AuthNotifier(prefs, AuthApi(dio), session,
      clock: () => now,
      policy: const SessionPolicy(
        idleTimeout: Duration(minutes: 3),
        idleWarning: Duration(seconds: 30),
        maxDuration: Duration(minutes: 60),
      ));

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    prefs = await SharedPreferences.getInstance();
    server = FakeServer();
    adapter = FakeAdapter(server.handle);
    session = ApiSession();
    dio = buildDio(session, baseUrl: 'http://test/api', log: (_) {})
      ..httpClientAdapter = adapter;
    now = DateTime(2026, 10, 29, 12);
  });

  Future<void> getBooks() => guard(() => dio.get<dynamic>('/books'));

  test('вход: токены сохранены, запросы идут с заголовком Authorization',
      () async {
    final auth = newAuth();
    await auth.login('reader', 'reader123');

    expect(auth.isAuthenticated, isTrue);
    expect(auth.user!.fullName, 'Смирнов П. А.');
    expect(prefs.getString(AuthNotifier.kAccess), 'access-1');
    expect(prefs.getString(AuthNotifier.kRefresh), 'refresh-1');

    await getBooks();
    expect(adapter.requests.last.headers['Authorization'], 'Bearer access-1');
    auth.dispose();
  });

  test('после перезагрузки страницы пользователь остаётся в системе', () async {
    await newAuth().login('reader', 'reader123');
    final requestsBefore = adapter.requests.length;

    final reloaded = newAuth(); // новая вкладка — та же память браузера
    await reloaded.restore();

    expect(reloaded.isAuthenticated, isTrue);
    expect(reloaded.user!.role, Role.reader);
    expect(adapter.requests.length, requestsBefore,
        reason: 'профиль взят из хранилища, повторный вход не нужен');
    reloaded.dispose();
  });

  test('неверный пароль: понятное сообщение и никаких попыток обновления',
      () async {
    final auth = newAuth();
    await expectLater(
      auth.login('reader', 'wrong'),
      throwsA(isA<UnauthorizedException>()
          .having((e) => e.message, 'message', 'Неверный логин или пароль')),
    );
    expect(adapter.log, ['POST /api/auth/login']);
    expect(auth.isAuthenticated, isFalse);
  });

  test('выход удаляет токены и аннулирует токен обновления на сервере',
      () async {
    final auth = newAuth();
    await auth.login('reader', 'reader123');
    await auth.logout();
    // Запрос на сервер уходит в фоне — даём ему завершиться.
    await Future<void>.delayed(const Duration(milliseconds: 50));

    expect(auth.isAuthenticated, isFalse);
    expect(prefs.getString(AuthNotifier.kAccess), isNull);
    expect(prefs.getString(AuthNotifier.kRefresh), isNull);
    expect(prefs.getString(AuthNotifier.kUser), isNull);
    expect(adapter.log.last, 'POST /api/auth/logout');
    expect(server.validRefresh, isEmpty);
  });

  test('401: токен обновляется, запрос повторяется незаметно', () async {
    final auth = newAuth();
    await auth.login('reader', 'reader123');
    server.expireAccess();

    await getBooks(); // не бросает исключение

    expect(adapter.log, [
      'POST /api/auth/login',
      'GET /api/books', // 401
      'POST /api/auth/refresh',
      'GET /api/books', // повтор с новым токеном
    ]);
    expect(adapter.requests.last.headers['Authorization'], 'Bearer access-2');
    expect(prefs.getString(AuthNotifier.kRefresh), 'refresh-2');
    auth.dispose();
  });

  test('обновление не удалось: один запрос refresh, выход, без зацикливания',
      () async {
    final auth = newAuth();
    await auth.login('reader', 'reader123');
    server
      ..expireAccess()
      ..refreshBroken = true;

    await expectLater(getBooks(), throwsA(isA<UnauthorizedException>()));

    expect(adapter.log.where((p) => p.endsWith('/auth/refresh')), hasLength(1));
    expect(adapter.log.where((p) => p.endsWith('/books')), hasLength(1));
    expect(auth.isAuthenticated, isFalse);
    expect(auth.lastLogout, LogoutReason.expired);
  });

  test('несколько запросов с 401 одновременно — одно обновление', () async {
    final auth = newAuth();
    await auth.login('reader', 'reader123');
    server.expireAccess();

    await Future.wait([getBooks(), getBooks(), getBooks()]);

    expect(adapter.log.where((p) => p.endsWith('/auth/refresh')), hasLength(1));
    auth.dispose();
  });

  test('подменённая роль живёт только в интерфейсе: при обновлении токена '
      'роль снова приходит с сервера', () async {
    await newAuth().login('reader', 'reader123');
    // «DevTools»: правим сохранённый профиль.
    final user = jsonDecode(prefs.getString(AuthNotifier.kUser)!) as Map;
    user['role'] = 'admin';
    await prefs.setString(AuthNotifier.kUser, jsonEncode(user));

    final auth = newAuth();
    await auth.restore();
    expect(auth.user!.role, Role.admin, reason: 'интерфейс поверил хранилищу');

    server.expireAccess();
    await getBooks();
    expect(auth.user!.role, Role.reader, reason: 'сервер вернул настоящую роль');
    auth.dispose();
  });

  test('после перезагрузки: долгая неактивность и предел сессии — выход',
      () async {
    await newAuth().login('reader', 'reader123');

    now = now.add(const Duration(minutes: 4));
    final idle = newAuth();
    await idle.restore();
    expect(idle.isAuthenticated, isFalse);
    expect(idle.lastLogout, LogoutReason.inactivity);

    await newAuth().login('reader', 'reader123');
    // Активность была, но с момента входа прошло больше часа.
    now = now.add(const Duration(minutes: 61));
    await prefs.setInt(AuthNotifier.kLastActivity, now.millisecondsSinceEpoch);
    final limited = newAuth();
    await limited.restore();
    expect(limited.isAuthenticated, isFalse);
    expect(limited.lastLogout, LogoutReason.sessionLimit);
  });
}
