import 'package:flutter/material.dart';

import '../auth/auth_notifier.dart';
import '../auth/permissions.dart';
import 'locations.dart';

/// Раздел приложения в меню и на главном экране.
class AppSection {
  const AppSection(this.path, this.icon, this.label, this.description,
      [this.permission]);

  final String path;
  final IconData icon;
  final String label;
  final String description;

  /// Право, без которого раздел не показывается (и не открывается —
  /// это проверяет redirect маршрута).
  final Permission? permission;
}

const appSections = <AppSection>[
  AppSection(homePath, Icons.home_outlined, 'Главная', 'Сводка и доступные разделы'),
  AppSection(booksPath, Icons.menu_book, 'Книги',
      'Каталог: поиск, фильтры, карточки книг', Permission.viewCatalog),
  AppSection(authorsPath, Icons.person, 'Авторы', 'Авторы и их книги',
      Permission.viewCatalog),
  AppSection(genresPath, Icons.category, 'Жанры', 'Жанры каталога',
      Permission.viewCatalog),
  AppSection(publishersPath, Icons.apartment, 'Издательства',
      'Издательства и их книги', Permission.viewCatalog),
  AppSection(readersPath, Icons.badge, 'Читатели',
      'Читатели и читательские билеты', Permission.manageReaders),
  AppSection(loansPath, Icons.swap_horiz, 'Выдачи',
      'Все выдачи: продление и закрытие', Permission.manageLoans),
  AppSection(myLoansPath, Icons.bookmarks_outlined, 'Мои выдачи',
      'Книги на руках, сроки, продление', Permission.viewOwnLoans),
  AppSection(usersPath, Icons.manage_accounts, 'Пользователи',
      'Учётные записи и роли', Permission.manageUsers),
  AppSection(statsPath, Icons.insights, 'Статистика',
      'Фонд, выдачи, читатели, пользователи', Permission.viewStats),
];

/// Разделы, доступные текущему пользователю.
List<AppSection> sectionsFor(AuthNotifier auth) => [
      for (final s in appSections)
        if (s.permission == null || auth.has(s.permission!)) s,
    ];

/// Раздел, к которому относится адрес: самый длинный совпавший префикс.
AppSection? sectionOf(String location, List<AppSection> sections) {
  AppSection? best;
  for (final s in sections) {
    final match = s.path == homePath
        ? location == homePath
        : location == s.path || location.startsWith('${s.path}/');
    if (match && (best == null || s.path.length > best.path.length)) best = s;
  }
  return best;
}
