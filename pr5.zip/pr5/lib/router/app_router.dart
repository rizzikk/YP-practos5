import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../auth/auth_notifier.dart';
import '../auth/permissions.dart';
import '../forms/entity_form.dart';
import '../models/author.dart';
import '../models/author_details.dart';
import '../models/author_query.dart';
import '../models/book.dart';
import '../models/book_query.dart';
import '../models/genre.dart';
import '../models/publisher.dart';
import '../models/reader.dart';
import '../repositories/author_repository.dart';
import '../repositories/book_repository.dart';
import '../repositories/loan_repository.dart';
import '../repositories/reader_repository.dart';
import '../repositories/reference_repository.dart';
import '../screens/admin_screens.dart';
import '../screens/app_shell.dart';
import '../screens/auth_screens.dart';
import '../screens/author_details_screen.dart';
import '../screens/author_form_screen.dart';
import '../screens/authors_list_screen.dart';
import '../screens/book_details_screen.dart';
import '../screens/book_form_screen.dart';
import '../screens/books_list_screen.dart';
import '../screens/forbidden_screen.dart';
import '../screens/genre_screens.dart';
import '../screens/home_screen.dart';
import '../screens/loan_screens.dart';
import '../screens/not_found_screen.dart';
import '../screens/publisher_screens.dart';
import '../screens/reader_screens.dart';
import '../state/details_notifier.dart';
import '../state/form_guard.dart';
import '../state/list_notifiers.dart';
import '../state/loans_list_notifier.dart';
import 'locations.dart';

/// Создаёт функцию загрузки записи. Репозитории берутся из провайдеров
/// здесь, в точке сборки; экраны к репозиториям не обращаются.
typedef LoaderFactory<T> = Future<T?> Function() Function(
    BuildContext context, int id);

/// Уход с экрана формы: при несохранённых изменениях — вопрос.
/// Срабатывает и при переходе по меню, и при кнопке «назад» браузера.
Future<bool> _confirmExit(BuildContext context, GoRouterState state) async {
  final guard = context.read<UnsavedChangesGuard>();
  if (!guard.dirty) return true;
  final leave = await confirmLeave(context);
  if (leave) guard.dirty = false;
  return leave;
}

Widget _withLoader<T>(
  GoRouterState state,
  LoaderFactory<T> loader,
  Widget Function(int id) screen,
) {
  final id = int.tryParse(state.pathParameters['id'] ?? '');
  if (id == null) return NotFoundScreen(location: state.uri.toString());
  return ChangeNotifierProvider(
    key: ValueKey(state.uri.path),
    create: (context) => DetailsNotifier<T>(loader(context, id))..load(),
    child: screen(id),
  );
}

/// Проверки маршрутов. Возвращают адрес перенаправления или `null` —
/// «переход разрешён». Это удобство интерфейса: человек не попадает
/// на экран, где ему всё равно откажет сервер. Защита — на сервере.
class _Guard {
  _Guard(this.auth);
  final AuthNotifier auth;

  /// Нет права — на экран отказа, с адресом и недостающим правом.
  String? need(GoRouterState state, Permission permission) {
    if (auth.has(permission)) return null;
    return Uri(path: forbiddenPath, queryParameters: {
      'from': state.uri.toString(),
      'need': permission.name,
    }).toString();
  }

  /// Удалённые записи показываются только тем, кто может их восстановить:
  /// параметр deleted из адреса у остальных молча убирается.
  String? list(GoRouterState state, Permission permission) {
    final denied = need(state, permission);
    if (denied != null) return denied;
    final params = state.uri.queryParameters;
    if (params.containsKey('deleted') && !auth.has(Permission.viewDeleted)) {
      final rest = Map.of(params)..remove('deleted');
      return Uri(path: state.uri.path, queryParameters: rest.isEmpty ? null : rest)
          .toString();
    }
    return null;
  }
}

GoRoute _list(_Guard guard, String path, Permission permission,
        Widget Function(Map<String, String> params) screen) =>
    GoRoute(
      path: path,
      redirect: (context, state) => guard.list(state, permission),
      // Постоянный ключ страницы: при смене параметров экран обновляется,
      // а не пересоздаётся — поле поиска не теряет фокус.
      pageBuilder: (context, state) => NoTransitionPage(
        key: ValueKey('$path-list'),
        child: screen(state.uri.queryParameters),
      ),
    );

/// Маршрут /new должен стоять раньше /:id, иначе «new» примется за id.
GoRoute _create(_Guard guard, String path, Permission permission, Widget form) =>
    GoRoute(
      path: newLocation(path),
      redirect: (context, state) => guard.need(state, permission),
      onExit: _confirmExit,
      builder: (context, state) => form,
    );

GoRoute _details<D>(_Guard guard, String path, Permission permission,
        LoaderFactory<D> loader, Widget Function(int id) screen) =>
    GoRoute(
      path: '$path/:id',
      redirect: (context, state) => guard.need(state, permission),
      builder: (context, state) => _withLoader<D>(state, loader, screen),
    );

GoRoute _edit<T>(_Guard guard, String path, Permission permission,
        LoaderFactory<T> loader, Widget Function(int id) form) =>
    GoRoute(
      path: '$path/:id/edit',
      redirect: (context, state) => guard.need(state, permission),
      onExit: _confirmExit,
      builder: (context, state) => _withLoader<T>(state, loader, form),
    );

GoRoute _page(_Guard guard, String path, Permission permission, Widget screen) =>
    GoRoute(
      path: path,
      redirect: (context, state) => guard.need(state, permission),
      pageBuilder: (context, state) =>
          NoTransitionPage(key: ValueKey(path), child: screen),
    );

/// Адрес из параметра from принимается, только если он внутренний:
/// иначе ссылка вида /login?from=https://чужой.сайт уводила бы наружу.
String? _safeFrom(String? from) {
  if (from == null || !from.startsWith('/') || from.startsWith('//')) return null;
  final path = Uri.tryParse(from)?.path;
  if (path == null || path == loginPath || path == registerPath) return null;
  return from;
}

/// Маршруты приложения. Адрес — единственный источник условий отбора:
/// экран списка получает их из параметров адреса, а не хранит у себя.
///
/// [refreshListenable] — сам [auth]: после входа, выхода и обновления токена
/// маршрутизатор заново вызывает redirect и уводит на нужный экран.
GoRouter createRouter(AuthNotifier auth) {
  final guard = _Guard(auth);
  const catalog = Permission.viewCatalog;
  const edit = Permission.editCatalog;
  const readers = Permission.manageReaders;
  return GoRouter(
    initialLocation: homePath,
    refreshListenable: auth,
    errorBuilder: (context, state) =>
        NotFoundScreen(location: state.uri.toString()),
    redirect: (context, state) {
      final loggedIn = auth.isAuthenticated;
      final path = state.uri.path;
      final isPublic = path == loginPath || path == registerPath;

      // Не вошёл и идёт на закрытый экран — на вход, запомнив адрес.
      // После явного «Выйти» адрес не запоминается.
      if (!loggedIn && !isPublic) {
        final from = state.uri.toString();
        if (auth.lastLogout == LogoutReason.manual || from == homePath) {
          return loginPath;
        }
        return Uri(path: loginPath, queryParameters: {'from': from}).toString();
      }

      // Уже вошёл и идёт на вход — туда, откуда увели, или на главную.
      if (loggedIn && isPublic) {
        return _safeFrom(state.uri.queryParameters['from']) ?? homePath;
      }
      return null;
    },
    routes: [
      GoRoute(
        path: loginPath,
        builder: (context, state) =>
            LoginScreen(from: state.uri.queryParameters['from']),
      ),
      GoRoute(
        path: registerPath,
        builder: (context, state) =>
            RegisterScreen(from: state.uri.queryParameters['from']),
      ),
      ShellRoute(
        builder: (context, state, child) =>
            AppShell(location: state.uri.path, child: child),
        routes: [
          GoRoute(
            path: homePath,
            pageBuilder: (context, state) => const NoTransitionPage(
                key: ValueKey('home'), child: HomeScreen()),
          ),
          GoRoute(
            path: forbiddenPath,
            pageBuilder: (context, state) => NoTransitionPage(
              key: ValueKey(state.uri.toString()),
              child: ForbiddenScreen(
                from: state.uri.queryParameters['from'],
                need: state.uri.queryParameters['need'],
              ),
            ),
          ),
          // ---------------------------------------------------- книги
          _list(guard, booksPath, catalog,
              (p) => BooksListScreen(query: BookQuery.fromQueryParameters(p))),
          _create(guard, booksPath, edit, const BookFormScreen()),
          _details<Book>(guard, booksPath, catalog, _bookLoader,
              (id) => BookDetailsScreen(id: id)),
          _edit<Book>(guard, booksPath, edit, _bookLoader,
              (id) => BookFormScreen(id: id)),
          // --------------------------------------------------- авторы
          _list(guard, authorsPath, catalog,
              (p) => AuthorsListScreen(query: AuthorQuery.fromQueryParameters(p))),
          _create(guard, authorsPath, edit, const AuthorFormScreen()),
          _details<AuthorDetails>(guard, authorsPath, catalog, (context, id) {
            final authors = context.read<AuthorRepository>();
            final books = context.read<BookRepository>();
            return () async {
              final author = await authors.findById(id);
              if (author == null) return null;
              return AuthorDetails(author: author, books: await books.findByAuthor(id));
            };
          }, (id) => AuthorDetailsScreen(id: id)),
          _edit<Author>(guard, authorsPath, edit, (context, id) {
            final authors = context.read<AuthorRepository>();
            return () => authors.findById(id);
          }, (id) => AuthorFormScreen(id: id)),
          // ---------------------------------------------------- жанры
          _list(guard, genresPath, catalog,
              (p) => GenresListScreen(query: genreListSpec.parse(p))),
          _create(guard, genresPath, edit, const GenreFormScreen()),
          _details<GenreDetails>(guard, genresPath, catalog, (context, id) {
            final genres = context.read<GenreRepository>();
            final books = context.read<BookRepository>();
            return () async {
              final genre = await genres.findById(id);
              if (genre == null) return null;
              return (genre: genre, books: await books.findByGenre(id));
            };
          }, (id) => GenreDetailsScreen(id: id)),
          _edit<Genre>(guard, genresPath, edit, (context, id) {
            final genres = context.read<GenreRepository>();
            return () => genres.findById(id);
          }, (id) => GenreFormScreen(id: id)),
          // --------------------------------------------- издательства
          _list(guard, publishersPath, catalog,
              (p) => PublishersListScreen(query: publisherListSpec.parse(p))),
          _create(guard, publishersPath, edit, const PublisherFormScreen()),
          _details<PublisherDetails>(guard, publishersPath, catalog, (context, id) {
            final publishers = context.read<PublisherRepository>();
            final books = context.read<BookRepository>();
            return () async {
              final publisher = await publishers.findById(id);
              if (publisher == null) return null;
              return (
                publisher: publisher,
                books: await books.findByPublisher(id),
              );
            };
          }, (id) => PublisherDetailsScreen(id: id)),
          _edit<Publisher>(guard, publishersPath, edit, (context, id) {
            final publishers = context.read<PublisherRepository>();
            return () => publishers.findById(id);
          }, (id) => PublisherFormScreen(id: id)),
          // ------------------------------------------------- читатели
          _list(guard, readersPath, readers,
              (p) => ReadersListScreen(query: readerListSpec.parse(p))),
          _create(guard, readersPath, readers, const ReaderFormScreen()),
          _details<Reader>(guard, readersPath, readers, _readerLoader,
              (id) => ReaderDetailsScreen(id: id)),
          _edit<Reader>(guard, readersPath, readers, _readerLoader,
              (id) => ReaderFormScreen(id: id)),
          // ---------------------------------------------------- выдачи
          _page(
            guard,
            loansPath,
            Permission.manageLoans,
            ChangeNotifierProvider(
              create: (context) =>
                  LoansListNotifier(context.read<LoanRepository>()),
              child: const LoansScreen(),
            ),
          ),
          _page(
            guard,
            myLoansPath,
            Permission.viewOwnLoans,
            ChangeNotifierProvider(
              // Номер читателя передаётся явно: если токен успел истечь,
              // сервер не определит пользователя по нему, а фильтр сохранится.
              create: (context) => LoansListNotifier(
                context.read<LoanRepository>(),
                query: LoanQuery(
                    readerId: context.read<AuthNotifier>().user?.readerId),
              ),
              child: const MyLoansScreen(),
            ),
          ),
          // ------------------------------------------- администратор
          _page(guard, usersPath, Permission.manageUsers, const UsersScreen()),
          _page(guard, statsPath, Permission.viewStats, const StatsScreen()),
        ],
      ),
    ],
  );
}

Future<Book?> Function() _bookLoader(BuildContext context, int id) {
  final books = context.read<BookRepository>();
  return () => books.findById(id);
}

Future<Reader?> Function() _readerLoader(BuildContext context, int id) {
  final readers = context.read<ReaderRepository>();
  return () => readers.findById(id);
}
