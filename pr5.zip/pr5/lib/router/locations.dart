import '../models/author_query.dart';
import '../models/book_query.dart';
import '../models/list_query.dart';

/// Адрес списка с условиями отбора в параметрах:
/// `/books?search=война&genreId=2&sort=year,desc&page=3`.
String booksLocation(BookQuery query) =>
    _location('/books', query.toQueryParameters());

String authorsLocation(AuthorQuery query) =>
    _location('/authors', query.toQueryParameters());

String bookLocation(int id) => '/books/$id';
String authorLocation(int id) => '/authors/$id';

String _location(String path, Map<String, String> params) =>
    Uri(path: path, queryParameters: params.isEmpty ? null : params).toString();

String listLocation(String basePath, ListQuery query) =>
    _location(basePath, query.toQueryParameters());

String newLocation(String basePath) => '$basePath/new';
String editLocation(String basePath, int id) => '$basePath/$id/edit';
String detailsLocation(String basePath, int id) => '$basePath/$id';

const booksPath = '/books';
const authorsPath = '/authors';
const genresPath = '/genres';
const publishersPath = '/publishers';
const readersPath = '/readers';

const homePath = '/';
const loginPath = '/login';
const registerPath = '/register';
const forbiddenPath = '/forbidden';
const loansPath = '/loans';
const myLoansPath = '/my-loans';
const usersPath = '/admin/users';
const statsPath = '/admin/stats';
