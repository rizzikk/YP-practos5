import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/api_exceptions.dart';
import '../core/config.dart';
import '../core/session.dart';
import 'app_user.dart';
import 'auth_api.dart';
import 'permissions.dart';

/// Почему завершилась сессия: от этого зависит сообщение на экране входа
/// и то, запоминать ли адрес, с которого пользователя увели.
enum LogoutReason { manual, inactivity, sessionLimit, expired }

/// Состояние входа: пользователь, токены, сроки сессии.
///
/// В localStorage (shared_preferences на web) лежат токены, время начала
/// сессии и последнего действия, а также профиль пользователя — только для
/// того, чтобы нарисовать интерфейс сразу после перезагрузки. Пароля там нет.
/// Права всё равно проверяет сервер по роли из подписанного токена.
class AuthNotifier extends ChangeNotifier {
  AuthNotifier(
    this._prefs,
    this._api,
    this._session, {
    this.policy = SessionPolicy.fromEnvironment,
    DateTime Function()? clock,
  }) : _now = clock ?? DateTime.now {
    _session.refresh = refreshTokens;
  }

  static const kAccess = 'auth_access_token';
  static const kRefresh = 'auth_refresh_token';
  static const kUser = 'auth_user';
  static const kStartedAt = 'auth_started_at';
  static const kLastActivity = 'auth_last_activity';

  final SharedPreferences _prefs;
  final AuthApi _api;
  final ApiSession _session;
  final SessionPolicy policy;
  final DateTime Function() _now;

  AppUser? _user;
  String? _refreshToken;
  DateTime? _startedAt;
  DateTime? _lastSavedActivity;
  Timer? _limitTimer;
  Future<bool>? _refreshing;
  LogoutReason? _lastLogout;

  AppUser? get user => _user;
  String? get accessToken => _session.accessToken;
  bool get isAuthenticated => _user != null && _session.accessToken != null;
  Role? get role => _user?.role;
  LogoutReason? get lastLogout => _lastLogout;

  /// Сообщение для экрана входа о том, почему сессия завершилась.
  String? get logoutMessage => switch (_lastLogout) {
        LogoutReason.inactivity => 'Сессия завершена: не было действий '
            'дольше ${_minutes(policy.idleTimeout)}. Войдите снова.',
        LogoutReason.sessionLimit => 'Сессия завершена: прошло '
            '${_minutes(policy.maxDuration)} с момента входа. '
            'Войдите снова.',
        LogoutReason.expired =>
          'Срок входа истёк, и обновить его не удалось. Войдите снова.',
        _ => null,
      };

  /// Когда сессия закончится независимо от активности.
  DateTime? get sessionEndsAt => _startedAt?.add(policy.maxDuration);

  bool has(Permission permission) => can(role, permission);

  // ------------------------------------------------------------ запуск

  /// Восстановление сессии при запуске приложения — один раз до построения
  /// дерева виджетов, иначе маршрутизатор успеет отправить на вход.
  Future<void> restore() async {
    final access = _prefs.getString(kAccess);
    final refresh = _prefs.getString(kRefresh);
    if (access == null || refresh == null) return;

    // Сроки проверяются и через перезагрузку: таймеры в памяти вкладки
    // обнуляются, а время начала и последнего действия лежат в хранилище.
    final now = _now();
    final started = _readTime(kStartedAt) ?? now;
    final last = _readTime(kLastActivity) ?? now;
    if (now.difference(started) >= policy.maxDuration) {
      await logout(reason: LogoutReason.sessionLimit);
      return;
    }
    if (now.difference(last) >= policy.idleTimeout) {
      await logout(reason: LogoutReason.inactivity);
      return;
    }

    _session.accessToken = access;
    _refreshToken = refresh;
    _startedAt = started;
    _user = _readUser();
    if (_user == null) {
      // Профиля нет — спрашиваем сервер. Истёкший токен обновляем.
      try {
        _user = await _api.me();
        await _saveUser();
      } on UnauthorizedException {
        if (!await refreshTokens()) return;
      } on ApiException {
        // Сервер недоступен: без профиля интерфейс не построить.
        _session.accessToken = null;
        _refreshToken = null;
        return;
      }
    }
    _scheduleLimit();
    notifyListeners();
  }

  // ------------------------------------------------------- вход и выход

  /// Неверный пароль — [UnauthorizedException] с текстом сервера.
  Future<void> login(String username, String password) async {
    final result = await _api.login(username.trim(), password);
    final now = _now();
    _startedAt = now;
    await _prefs.setInt(kStartedAt, now.millisecondsSinceEpoch);
    await _prefs.setInt(kLastActivity, now.millisecondsSinceEpoch);
    _lastSavedActivity = now;
    _lastLogout = null;
    await _apply(result);
    _scheduleLimit();
    notifyListeners();
  }

  /// Регистрация и сразу вход под новой учётной записью.
  /// Ошибки полей приходят как [ValidationException] (422).
  Future<void> register({
    required String username,
    required String password,
    required String email,
    required String fullName,
  }) async {
    await _api.register(
      username: username.trim(),
      password: password,
      email: email.trim(),
      fullName: fullName.trim(),
    );
    await login(username, password);
  }

  Future<void> logout({LogoutReason reason = LogoutReason.manual}) async {
    final refresh = _refreshToken;
    _user = null;
    _refreshToken = null;
    _startedAt = null;
    _session.accessToken = null;
    _limitTimer?.cancel();
    _limitTimer = null;
    _lastLogout = reason;
    for (final key in const [kAccess, kRefresh, kUser, kStartedAt, kLastActivity]) {
      await _prefs.remove(key);
    }
    notifyListeners();
    // Токен обновления аннулируется и на сервере. Ошибка здесь не важна:
    // локально пользователь уже вышел.
    if (refresh != null && reason != LogoutReason.expired) {
      unawaited(_api.logout(refresh).then((_) {}, onError: (_) {}));
    }
  }

  // -------------------------------------------------- обновление токена

  /// Обновить пару токенов. Одновременные вызовы (несколько запросов
  /// получили 401 разом) объединяются в один запрос к серверу.
  /// Неудача — выход из системы; повторных попыток нет, поэтому
  /// зацикливания не возникает.
  Future<bool> refreshTokens() =>
      _refreshing ??= _refresh().whenComplete(() => _refreshing = null);

  Future<bool> _refresh() async {
    final token = _refreshToken ?? _prefs.getString(kRefresh);
    if (token == null) return false;
    try {
      final result = await _api.refresh(token);
      await _apply(result);
      notifyListeners();
      return true;
    } on NetworkException {
      // Сервер недоступен — сессию не сбрасываем, запрос просто не удался.
      return false;
    } on ApiException {
      await logout(reason: LogoutReason.expired);
      return false;
    }
  }

  // ------------------------------------------------------ активность

  /// Отметка действия пользователя. В хранилище пишется не чаще раза
  /// в 5 секунд — движение мыши не должно превращаться в поток записей.
  void touch() {
    if (!isAuthenticated) return;
    final now = _now();
    final last = _lastSavedActivity;
    if (last != null && now.difference(last) < const Duration(seconds: 5)) {
      return;
    }
    _lastSavedActivity = now;
    unawaited(_prefs.setInt(kLastActivity, now.millisecondsSinceEpoch));
  }

  // ------------------------------------------------------------- служебное

  Future<void> _apply(AuthResult result) async {
    _session.accessToken = result.accessToken;
    _refreshToken = result.refreshToken;
    // Роль всегда берётся из ответа сервера — и при входе, и при каждом
    // обновлении токена.
    _user = result.user;
    await _prefs.setString(kAccess, result.accessToken);
    await _prefs.setString(kRefresh, result.refreshToken);
    await _saveUser();
  }

  Future<void> _saveUser() async {
    final user = _user;
    if (user == null) return;
    await _prefs.setString(kUser, jsonEncode(user.toJson()));
  }

  AppUser? _readUser() {
    final raw = _prefs.getString(kUser);
    if (raw == null) return null;
    try {
      final data = jsonDecode(raw);
      return data is Map ? AppUser.fromJson(Map<String, dynamic>.from(data)) : null;
    } on FormatException {
      return null;
    }
  }

  DateTime? _readTime(String key) {
    final ms = _prefs.getInt(key);
    return ms == null ? null : DateTime.fromMillisecondsSinceEpoch(ms);
  }

  void _scheduleLimit() {
    _limitTimer?.cancel();
    final ends = sessionEndsAt;
    if (ends == null) return;
    var left = ends.difference(_now());
    if (left.isNegative) left = Duration.zero;
    _limitTimer = Timer(left, () => logout(reason: LogoutReason.sessionLimit));
  }

  static String _minutes(Duration d) {
    if (d.inSeconds < 60) return '${d.inSeconds} с';
    final m = d.inMinutes;
    final word = m % 10 == 1 && m % 100 != 11
        ? 'минуты'
        : 'минут';
    return '$m $word';
  }

  @override
  void dispose() {
    _limitTimer?.cancel();
    super.dispose();
  }
}
