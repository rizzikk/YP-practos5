import '../models/json_utils.dart';
import 'permissions.dart';

/// Пользователь системы — так, как его описал сервер.
class AppUser {
  final int id;
  final String username;
  final String fullName;
  final String email;
  final Role role;

  /// Читатель, привязанный к учётной записи (у сотрудников — нет).
  final int? readerId;

  const AppUser({
    required this.id,
    required this.username,
    required this.fullName,
    required this.role,
    this.email = '',
    this.readerId,
  });

  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(
        id: readInt(json['id']),
        username: readString(json['username']),
        fullName: readString(json['fullName'], readString(json['username'])),
        email: readString(json['email']),
        role: Role.parse(json['role']),
        readerId: readIntOrNull(json['readerId']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'fullName': fullName,
        'email': email,
        'role': role.name,
        'readerId': readerId,
      };

  AppUser copyWith({Role? role}) => AppUser(
        id: id,
        username: username,
        fullName: fullName,
        email: email,
        role: role ?? this.role,
        readerId: readerId,
      );
}

/// Ответ на вход и обновление: пара токенов и пользователь.
class AuthResult {
  final String accessToken;
  final String refreshToken;
  final Duration expiresIn;
  final AppUser user;

  const AuthResult({
    required this.accessToken,
    required this.refreshToken,
    required this.expiresIn,
    required this.user,
  });

  factory AuthResult.fromJson(Map<String, dynamic> json) => AuthResult(
        accessToken: readString(json['accessToken']),
        refreshToken: readString(json['refreshToken']),
        expiresIn: Duration(seconds: readInt(json['expiresIn'], 900)),
        user: AppUser.fromJson(readMap(json['user'])),
      );
}
