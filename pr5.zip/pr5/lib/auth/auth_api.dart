import 'package:dio/dio.dart';

import '../core/api_exceptions.dart';
import '../models/json_utils.dart';
import 'app_user.dart';

/// Запросы раздела «Аутентификация» учебного API.
///
/// Пароль отправляется как есть: хеширует его сервер. Хеш, посчитанный
/// на клиенте, просто стал бы новым паролем.
class AuthApi {
  AuthApi(this._dio);

  final Dio _dio;

  /// Вход, регистрация и обновление идут без токена доступа.
  static Options get _public => Options(extra: {'skipAuth': true});

  Future<AuthResult> login(String username, String password) =>
      guard(() async {
        final response = await _dio.post<dynamic>('/auth/login',
            data: {'username': username, 'password': password},
            options: _public);
        return AuthResult.fromJson(readMap(response.data));
      });

  /// Новый пользователь на сервере всегда получает роль reader.
  Future<AppUser> register({
    required String username,
    required String password,
    required String email,
    required String fullName,
  }) =>
      guard(() async {
        final response = await _dio.post<dynamic>('/auth/register',
            data: {
              'username': username,
              'password': password,
              'email': email,
              'fullName': fullName,
            },
            options: _public);
        return AppUser.fromJson(readMap(response.data));
      });

  Future<AuthResult> refresh(String refreshToken) => guard(() async {
        final response = await _dio.post<dynamic>('/auth/refresh',
            data: {'refreshToken': refreshToken}, options: _public);
        return AuthResult.fromJson(readMap(response.data));
      });

  Future<AppUser> me() => guard(() async {
        final response = await _dio.get<dynamic>('/auth/me');
        return AppUser.fromJson(readMap(response.data));
      });

  /// Аннулировать токен обновления на сервере.
  Future<void> logout(String refreshToken) => guard(() => _dio.post<dynamic>(
      '/auth/logout',
      data: {'refreshToken': refreshToken},
      options: _public));
}
