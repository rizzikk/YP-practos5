/// Роли и права. Это единственное место, где записано, какой роли что
/// доступно: маршрутизатор, меню и кнопки спрашивают только [can].
///
/// Важно: всё это — удобство интерфейса. Решение «разрешить операцию»
/// принимает сервер по роли из подписанного токена, а не по тому, что
/// думает о пользователе клиент.
library;

enum Role {
  reader('Читатель'),
  librarian('Библиотекарь'),
  admin('Администратор');

  const Role(this.label);
  final String label;

  /// Роль из ответа сервера. Неизвестное значение — самая слабая роль,
  /// а не исключение: интерфейс просто покажет меньше.
  static Role parse(Object? value) => switch (value) {
        'admin' => Role.admin,
        'librarian' => Role.librarian,
        _ => Role.reader,
      };
}

/// Операции, доступ к которым различается по ролям.
enum Permission {
  viewCatalog('Просмотр каталога, авторов, жанров, издательств'),
  editCatalog('Создание, изменение и удаление книг и справочников'),
  viewOwnLoans('Просмотр собственных выдач'),
  extendOwnLoan('Продление срока своей выдачи'),
  manageLoans('Оформление, продление и закрытие выдач'),
  manageReaders('Работа с читателями'),
  viewDeleted('Просмотр удалённых записей'),
  restore('Восстановление записей'),
  hardDelete('Физическое удаление'),
  manageUsers('Управление пользователями и ролями'),
  viewStats('Просмотр статистики');

  const Permission(this.label);
  final String label;
}

/// Набор прав каждой роли. Роли различаются составом функций, а не объёмом
/// одного и того же: у каждой есть экран, которого нет у остальных
/// («Мои выдачи» — читатель, «Выдачи» — библиотекарь,
/// «Пользователи» и «Статистика» — администратор).
const Map<Role, Set<Permission>> rolePermissions = {
  Role.reader: {
    Permission.viewCatalog,
    Permission.viewOwnLoans,
    Permission.extendOwnLoan,
  },
  Role.librarian: {
    Permission.viewCatalog,
    Permission.editCatalog,
    Permission.manageLoans,
    Permission.manageReaders,
  },
  Role.admin: {
    Permission.viewCatalog,
    Permission.editCatalog,
    Permission.manageReaders,
    Permission.viewDeleted,
    Permission.restore,
    Permission.hardDelete,
    Permission.manageUsers,
    Permission.viewStats,
  },
};

/// Есть ли у роли право. Без роли (не вошёл) — нет никаких прав.
bool can(Role? role, Permission permission) =>
    role != null && (rolePermissions[role]?.contains(permission) ?? false);
