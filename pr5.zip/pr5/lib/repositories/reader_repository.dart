import '../models/list_query.dart';
import '../models/reader.dart';
import 'crud_repository.dart';

abstract interface class ReaderRepository
    implements CrudRepository<Reader, ListQuery> {}
