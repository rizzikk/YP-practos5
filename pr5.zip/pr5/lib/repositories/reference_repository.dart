import '../models/genre.dart';
import '../models/list_query.dart';
import '../models/publisher.dart';
import 'crud_repository.dart';

/// Справочники: жанры и издательства.
abstract interface class GenreRepository
    implements CrudRepository<Genre, ListQuery> {}

abstract interface class PublisherRepository
    implements CrudRepository<Publisher, ListQuery> {}
