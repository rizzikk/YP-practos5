import 'package:dio/dio.dart';

import '../core/api_exceptions.dart';
import '../models/page_result.dart';
import 'crud_repository.dart';

/// Общая реализация [CrudRepository] поверх учебного API. Поиск, фильтры,
/// сортировка и постраничный вывод выполняет сервер: клиент хранит только
/// текущую страницу.
abstract class ApiCrudRepository<T, Q> implements CrudRepository<T, Q> {
  ApiCrudRepository(this.dio, this.path);

  final Dio dio;

  /// Путь ресурса: `/books`, `/authors`…
  final String path;

  /// Токен последнего запроса списка: новый запрос отменяет предыдущий,
  /// чтобы устаревший ответ не перезаписал свежий.
  CancelToken? _listToken;

  T fromJson(Map<String, dynamic> json);
  Map<String, dynamic> toInput(T entity);
  int idOf(T entity);

  /// Условия отбора → параметры запроса `GET path`.
  Map<String, dynamic> queryParams(Q query);

  PageResult<T> parsePage(Object? data, {int fallbackSize = 10}) {
    final map = data is Map ? data : const {};
    final items = map['items'];
    return PageResult(
      items: items is List
          ? items
              .whereType<Map>()
              .map((e) => fromJson(Map<String, dynamic>.from(e)))
              .toList()
          : <T>[],
      page: map['page'] is int ? map['page'] as int : 1,
      size: map['size'] is int ? map['size'] as int : fallbackSize,
      total: map['total'] is int ? map['total'] as int : 0,
    );
  }

  @override
  Future<PageResult<T>> find(Q query) {
    _listToken?.cancel('устаревший запрос');
    final token = _listToken = CancelToken();
    return guard(() async {
      final response = await dio.get<dynamic>(path,
          queryParameters: queryParams(query), cancelToken: token);
      return parsePage(response.data);
    });
  }

  /// Выборка «всё сразу» для справочников: по 100 записей за запрос.
  Future<List<T>> fetchAll(Map<String, dynamic> params) => guard(() async {
        final all = <T>[];
        var page = 1;
        while (true) {
          final response = await dio.get<dynamic>(path,
              queryParameters: {...params, 'page': page, 'size': 100});
          final result = parsePage(response.data, fallbackSize: 100);
          all.addAll(result.items);
          if (!result.hasNext || result.items.isEmpty) return all;
          page++;
        }
      });

  @override
  Future<List<T>> findAll() => fetchAll({'includeDeleted': true});

  @override
  Future<T?> findById(int id) async {
    try {
      return await guard(() async {
        final response = await dio.get<dynamic>('$path/$id',
            queryParameters: {'includeDeleted': true});
        return fromJson(Map<String, dynamic>.from(response.data as Map));
      });
    } on NotFoundException {
      return null;
    }
  }

  @override
  Future<T> create(T entity) => guard(() async {
        final response = await dio.post<dynamic>(path, data: toInput(entity));
        return fromJson(Map<String, dynamic>.from(response.data as Map));
      });

  @override
  Future<T> update(T entity) => guard(() async {
        final response =
            await dio.put<dynamic>('$path/${idOf(entity)}', data: toInput(entity));
        return fromJson(Map<String, dynamic>.from(response.data as Map));
      });

  @override
  Future<void> softDelete(int id) => guard(() => dio.delete<dynamic>('$path/$id'));

  @override
  Future<void> hardDelete(int id) => guard(
      () => dio.delete<dynamic>('$path/$id', queryParameters: {'hard': true}));

  @override
  Future<void> restore(int id) =>
      guard(() => dio.post<dynamic>('$path/$id/restore'));

  @override
  Future<int> deleteMany(List<int> ids) => guard(() async {
        final response =
            await dio.post<dynamic>('$path/bulk-delete', data: {'ids': ids});
        final data = response.data;
        return data is Map && data['deleted'] is int ? data['deleted'] as int : 0;
      });
}

/// Сортировка в формате API: `title,asc`.
String apiSort(String field, bool ascending) =>
    '$field,${ascending ? 'asc' : 'desc'}';
