import '../models/loan.dart';
import '../models/page_result.dart';

/// Условия отбора выдач. Поиска по тексту у выдач на сервере нет,
/// есть фильтр по состоянию и по читателю.
class LoanQuery {
  const LoanQuery({this.status, this.readerId, this.page = 1, this.size = 25});

  /// `active`, `overdue`, `returned` или `null` — все.
  final String? status;

  /// Только выдачи этого читателя.
  final int? readerId;
  final int page;
  final int size;

  LoanQuery copyWith(
          {String? status, bool clearStatus = false, int? page, int? size}) =>
      LoanQuery(
        status: clearStatus ? null : status ?? this.status,
        readerId: readerId,
        page: page ?? this.page,
        size: size ?? this.size,
      );
}

/// Выдачи книг.
abstract interface class LoanRepository {
  /// Список выдач. Читателю сервер по токену возвращает только его выдачи.
  Future<PageResult<Loan>> find(LoanQuery query);

  /// Оформить выдачу. Нет свободных экземпляров — [ConflictException] (409).
  Future<Loan> issue({required int readerId, required int bookId, int days});

  /// Продлить срок возврата на [days] дней от текущего срока.
  Future<Loan> extend(Loan loan, {int days});

  /// Закрыть выдачу (книга возвращена).
  Future<Loan> close(int id);
}
