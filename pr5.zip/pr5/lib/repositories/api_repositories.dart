import 'package:dio/dio.dart';

import '../auth/app_user.dart';
import '../auth/permissions.dart';
import '../core/api_exceptions.dart';
import '../models/author.dart';
import '../models/author_query.dart';
import '../models/book.dart';
import '../models/book_query.dart';
import '../models/genre.dart';
import '../models/list_query.dart';
import '../models/loan.dart';
import '../models/page_result.dart';
import '../models/publisher.dart';
import '../models/reader.dart';
import 'api_repository.dart';
import 'author_repository.dart';
import 'book_repository.dart';
import 'loan_repository.dart';
import 'reader_repository.dart';
import 'reference_repository.dart';
import 'user_repository.dart';

/// Имена полей сортировки в интерфейсе → имена полей на сервере.
const _bookSortFields = {'available': 'copiesAvailable'};

class ApiBookRepository extends ApiCrudRepository<Book, BookQuery>
    implements BookRepository {
  ApiBookRepository(Dio dio) : super(dio, '/books');

  @override
  Book fromJson(Map<String, dynamic> json) => Book.fromJson(json);
  @override
  Map<String, dynamic> toInput(Book entity) => entity.toInput();
  @override
  int idOf(Book entity) => entity.id;

  @override
  Map<String, dynamic> queryParams(BookQuery q) => {
        if (q.search.trim().isNotEmpty) 'search': q.search.trim(),
        if (q.genreId != null) 'genreId': q.genreId,
        if (q.publisherId != null) 'publisherId': q.publisherId,
        if (q.yearFrom != null) 'yearFrom': q.yearFrom,
        if (q.yearTo != null) 'yearTo': q.yearTo,
        'sort': apiSort(_bookSortFields[q.sortField] ?? q.sortField, q.sortAscending),
        'page': q.page,
        'size': q.size,
        if (q.includeDeleted) 'includeDeleted': true,
      };

  @override
  Future<List<Book>> findByAuthor(int authorId) =>
      fetchAll({'authorId': authorId, 'includeDeleted': true, 'sort': 'year,asc'});

  @override
  Future<List<Book>> findByGenre(int genreId) =>
      fetchAll({'genreId': genreId, 'includeDeleted': true, 'sort': 'year,asc'});

  @override
  Future<List<Book>> findByPublisher(int publisherId) => fetchAll(
      {'publisherId': publisherId, 'includeDeleted': true, 'sort': 'year,asc'});

  @override
  Future<int> countByPublisher(int publisherId) => guard(() async {
        final response = await dio.get<dynamic>(path, queryParameters: {
          'publisherId': publisherId,
          'includeDeleted': true,
          'size': 1,
        });
        return parsePage(response.data).total;
      });
}

class ApiAuthorRepository extends ApiCrudRepository<Author, AuthorQuery>
    implements AuthorRepository {
  ApiAuthorRepository(Dio dio) : super(dio, '/authors');

  @override
  Author fromJson(Map<String, dynamic> json) => Author.fromJson(json);
  @override
  Map<String, dynamic> toInput(Author entity) => entity.toInput();
  @override
  int idOf(Author entity) => entity.id;

  @override
  Map<String, dynamic> queryParams(AuthorQuery q) => {
        if (q.search.trim().isNotEmpty) 'search': q.search.trim(),
        'sort': apiSort(q.sortField, q.sortAscending),
        'page': q.page,
        'size': q.size,
        if (q.includeDeleted) 'includeDeleted': true,
      };
}

/// Параметры для простых списков (жанры, издательства, читатели).
Map<String, dynamic> _listParams(ListQuery q) => {
      if (q.search.trim().isNotEmpty) 'search': q.search.trim(),
      'sort': apiSort(q.sortField, q.sortAscending),
      'page': q.page,
      'size': q.size,
      if (q.includeDeleted) 'includeDeleted': true,
    };

class ApiGenreRepository extends ApiCrudRepository<Genre, ListQuery>
    implements GenreRepository {
  ApiGenreRepository(Dio dio) : super(dio, '/genres');

  @override
  Genre fromJson(Map<String, dynamic> json) => Genre.fromJson(json);
  @override
  Map<String, dynamic> toInput(Genre entity) => entity.toInput();
  @override
  int idOf(Genre entity) => entity.id;
  @override
  Map<String, dynamic> queryParams(ListQuery q) => _listParams(q);
}

class ApiPublisherRepository extends ApiCrudRepository<Publisher, ListQuery>
    implements PublisherRepository {
  ApiPublisherRepository(Dio dio) : super(dio, '/publishers');

  @override
  Publisher fromJson(Map<String, dynamic> json) => Publisher.fromJson(json);
  @override
  Map<String, dynamic> toInput(Publisher entity) => entity.toInput();
  @override
  int idOf(Publisher entity) => entity.id;
  @override
  Map<String, dynamic> queryParams(ListQuery q) => _listParams(q);
}

class ApiReaderRepository extends ApiCrudRepository<Reader, ListQuery>
    implements ReaderRepository {
  ApiReaderRepository(Dio dio) : super(dio, '/readers');

  @override
  Reader fromJson(Map<String, dynamic> json) => Reader.fromJson(json);
  @override
  Map<String, dynamic> toInput(Reader entity) => entity.toInput();
  @override
  int idOf(Reader entity) => entity.id;
  @override
  Map<String, dynamic> queryParams(ListQuery q) => _listParams(q);
}

/// Страница в оболочке учебного API → [PageResult].
PageResult<T> _page<T>(Object? data, T Function(Map<String, dynamic>) parse) {
  final map = data is Map ? data : const {};
  final items = map['items'];
  return PageResult(
    items: items is List
        ? items
            .whereType<Map>()
            .map((e) => parse(Map<String, dynamic>.from(e)))
            .toList()
        : <T>[],
    page: map['page'] is int ? map['page'] as int : 1,
    size: map['size'] is int ? map['size'] as int : 10,
    total: map['total'] is int ? map['total'] as int : 0,
  );
}

Loan _loan(Object? data) =>
    Loan.fromJson(Map<String, dynamic>.from(data as Map));

class ApiLoanRepository implements LoanRepository {
  ApiLoanRepository(this._dio);
  final Dio _dio;

  @override
  Future<PageResult<Loan>> find(LoanQuery query) => guard(() async {
        final response = await _dio.get<dynamic>('/loans', queryParameters: {
          if (query.status != null) 'status': query.status,
          if (query.readerId != null) 'readerId': query.readerId,
          'sort': 'dueAt,asc',
          'page': query.page,
          'size': query.size,
        });
        return _page(response.data, Loan.fromJson);
      });

  @override
  Future<Loan> issue({required int readerId, required int bookId, int days = 14}) =>
      guard(() async {
        final response = await _dio.post<dynamic>('/loans',
            data: {'readerId': readerId, 'bookId': bookId, 'days': days});
        return _loan(response.data);
      });

  /// Новый срок считается от текущего срока возврата, а для просроченной
  /// выдачи — от сегодняшнего дня.
  @override
  Future<Loan> extend(Loan loan, {int days = 14}) => guard(() async {
        final now = DateTime.now();
        final due = loan.dueAt;
        final from = due == null || due.isBefore(now) ? now : due;
        final response = await _dio.patch<dynamic>('/loans/${loan.id}', data: {
          'dueAt': from.add(Duration(days: days)).toUtc().toIso8601String(),
        });
        return _loan(response.data);
      });

  @override
  Future<Loan> close(int id) => guard(() async {
        final response = await _dio.post<dynamic>('/loans/$id/return');
        return _loan(response.data);
      });
}

class ApiUserRepository implements UserRepository {
  ApiUserRepository(this._dio);
  final Dio _dio;

  @override
  Future<PageResult<AppUser>> find(
          {int page = 1, int size = 50, String sort = 'id,asc'}) =>
      guard(() async {
        final response = await _dio.get<dynamic>('/users',
            queryParameters: {'page': page, 'size': size, 'sort': sort});
        return _page(response.data, AppUser.fromJson);
      });

  @override
  Future<AppUser> changeRole(int id, Role role) => guard(() async {
        final response =
            await _dio.patch<dynamic>('/users/$id', data: {'role': role.name});
        return AppUser.fromJson(Map<String, dynamic>.from(response.data as Map));
      });
}
