import '../models/book.dart';
import '../models/book_query.dart';
import 'crud_repository.dart';

/// Операции с книгами: общий набор из [CrudRepository] плюс выборки
/// по связям. Интерфейс тот же, что в ПР2–ПР3, — поменялась только реализация.
abstract interface class BookRepository
    implements CrudRepository<Book, BookQuery> {
  /// Все книги автора, включая удалённые (для карточки автора).
  Future<List<Book>> findByAuthor(int authorId);

  /// Книги жанра и издательства — для их карточек.
  Future<List<Book>> findByGenre(int genreId);
  Future<List<Book>> findByPublisher(int publisherId);

  /// Сколько книг ссылается на издательство — для запрета его удаления.
  Future<int> countByPublisher(int publisherId);
}
