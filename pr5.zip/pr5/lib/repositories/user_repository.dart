import '../auth/app_user.dart';
import '../auth/permissions.dart';
import '../models/page_result.dart';

/// Учётные записи пользователей. Доступно только администратору —
/// остальным сервер отвечает 403.
abstract interface class UserRepository {
  Future<PageResult<AppUser>> find({int page, int size, String sort});

  /// Сменить роль пользователя.
  Future<AppUser> changeRole(int id, Role role);
}
