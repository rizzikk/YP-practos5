import 'package:flutter/foundation.dart';

import 'load_status.dart';

/// Состояние экрана карточки. Источник данных передаётся функцией, поэтому
/// один класс обслуживает и карточку книги, и карточку автора.
class DetailsNotifier<T> extends ChangeNotifier {
  DetailsNotifier(this._loader);

  /// Возвращает `null`, если запись не найдена.
  final Future<T?> Function() _loader;

  T? _data;
  LoadStatus _status = LoadStatus.idle;
  String? _error;
  bool _disposed = false;

  T? get data => _data;
  LoadStatus get status => _status;
  String? get error => _error;
  bool get notFound => _status == LoadStatus.success && _data == null;

  Future<void> load() async {
    _status = LoadStatus.loading;
    _error = null;
    _notify();
    try {
      _data = await _loader();
      _status = LoadStatus.success;
    } catch (e) {
      _error = 'Не удалось загрузить запись: $e';
      _status = LoadStatus.error;
    }
    _notify();
  }

  // Пользователь мог уйти со страницы, пока шла загрузка.
  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
