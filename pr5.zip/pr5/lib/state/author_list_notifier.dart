import 'package:flutter/foundation.dart';

import '../models/author.dart';
import '../models/author_query.dart';
import '../repositories/author_repository.dart';
import 'entity_list_notifier.dart';

class AuthorListNotifier extends EntityListNotifier<Author, AuthorQuery> {
  AuthorListNotifier(AuthorRepository repository, {VoidCallback? onChanged})
      : super(repository, const AuthorQuery(), onChanged: onChanged);
}
