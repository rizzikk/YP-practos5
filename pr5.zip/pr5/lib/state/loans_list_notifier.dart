import 'package:flutter/foundation.dart';

import '../models/loan.dart';
import '../models/page_result.dart';
import '../repositories/loan_repository.dart';
import 'load_status.dart';

/// Список выдач. Один класс обслуживает и «Мои выдачи» читателя, и «Выдачи»
/// библиотекаря: какие записи вернуть, решает сервер по токену.
class LoansListNotifier extends ChangeNotifier {
  LoansListNotifier(this._repository, {LoanQuery query = const LoanQuery()})
      : _query = query;

  final LoanRepository _repository;
  LoanQuery _query;
  PageResult<Loan> _result = PageResult<Loan>.empty();
  LoadStatus _status = LoadStatus.idle;
  String? _error;
  int _request = 0;
  bool _disposed = false;

  /// Выдачи, по которым сейчас идёт запрос: кнопка у такой строки
  /// заблокирована, повторное нажатие не отправит второй запрос.
  final Set<int> _busy = {};

  LoanQuery get query => _query;
  PageResult<Loan> get result => _result;
  LoadStatus get status => _status;
  String? get error => _error;
  bool isBusy(int id) => _busy.contains(id);

  Future<void> load() async {
    final request = ++_request;
    _status = LoadStatus.loading;
    _error = null;
    _notify();
    try {
      final result = await _repository.find(_query);
      if (request != _request) return;
      _result = result;
      _status = LoadStatus.success;
    } catch (e) {
      if (request != _request) return;
      _error = 'Не удалось загрузить выдачи: $e';
      _status = LoadStatus.error;
    }
    _notify();
  }

  Future<void> setStatusFilter(String? status) {
    _query = _query.copyWith(
        status: status, clearStatus: status == null, page: 1);
    return load();
  }

  Future<void> setSize(int size) {
    _query = _query.copyWith(size: size, page: 1);
    return load();
  }

  Future<void> setPage(int page) {
    _query = _query.copyWith(page: page);
    return load();
  }

  /// Продлить на 14 дней. Ошибка (в том числе 403) пробрасывается экрану.
  Future<Loan> extend(Loan loan) => _run(loan.id, () => _repository.extend(loan));

  /// Закрыть выдачу.
  Future<Loan> close(Loan loan) => _run(loan.id, () => _repository.close(loan.id));

  Future<Loan> _run(int id, Future<Loan> Function() action) async {
    _busy.add(id);
    _notify();
    try {
      final loan = await action();
      await load();
      return loan;
    } finally {
      _busy.remove(id);
      _notify();
    }
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
