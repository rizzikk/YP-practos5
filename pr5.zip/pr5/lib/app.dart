import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import 'auth/auth_notifier.dart';
import 'router/app_router.dart';
import 'widgets/inactivity_watcher.dart';

class LibraryApp extends StatefulWidget {
  const LibraryApp({super.key});

  @override
  State<LibraryApp> createState() => _LibraryAppState();
}

class _LibraryAppState extends State<LibraryApp> {
  // Маршрутизатор создаётся один раз, а не при каждой перестройке.
  late final GoRouter _router;
  final _messenger = GlobalKey<ScaffoldMessengerState>();

  @override
  void initState() {
    super.initState();
    _router = createRouter(context.read<AuthNotifier>());
  }

  @override
  void dispose() {
    _router.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Библиотека',
      debugShowCheckedModeBanner: false,
      scaffoldMessengerKey: _messenger,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF3F51B5),
        useMaterial3: true,
      ),
      locale: const Locale('ru'),
      supportedLocales: const [Locale('ru')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      routerConfig: _router,
      // Выход по неактивности отслеживается над всем приложением,
      // но только пока пользователь вошёл.
      builder: (context, child) {
        final auth = context.watch<AuthNotifier>();
        return InactivityWatcher(
          enabled: auth.isAuthenticated,
          timeout: auth.policy.idleTimeout,
          warning: auth.policy.idleWarning,
          onActivity: auth.touch,
          onTimeout: () => auth.logout(reason: LogoutReason.inactivity),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
  }
}
