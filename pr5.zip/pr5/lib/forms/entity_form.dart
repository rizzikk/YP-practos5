import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../core/api_exceptions.dart';
import '../state/details_notifier.dart';
import '../state/form_guard.dart';
import '../widgets/dialogs.dart';
import '../widgets/state_views.dart';
import 'validators.dart';

// ------------------------------------------------------------ описание полей

/// Описание поля формы. Форма любой сущности задаётся списком таких описаний,
/// а виджет [EntityForm] общий для всех.
sealed class FieldSpec {
  const FieldSpec(this.key, this.label);
  final String key;
  final String label;
}

/// Текстовое или числовое поле.
class TextFieldSpec extends FieldSpec {
  const TextFieldSpec(
    super.key,
    super.label, {
    this.validator,
    this.hint,
    this.helper,
    this.numeric = false,
    this.maxLines = 1,
    this.width,
    this.readOnly = false,
  });

  final Validator? validator;

  /// Значение задаёт сервер — поле только показывается.
  final bool readOnly;
  final String? hint;
  final String? helper;
  final bool numeric;
  final int maxLines;

  /// Ширина поля; `null` — во всю строку.
  final double? width;
}

/// Выбор одного значения из списка — связь «многие к одному».
class ChoiceFieldSpec extends FieldSpec {
  const ChoiceFieldSpec(
    super.key,
    super.label, {
    required this.options,
    this.requiredMessage,
    this.helper,
    this.width,
  });

  /// Пары «значение — подпись». Значение — идентификатор, а не объект:
  /// так выбранное значение всегда совпадает с элементом списка.
  final List<(Object, String)> options;
  final String? requiredMessage;
  final String? helper;
  final double? width;
}

/// Выбор нескольких значений — связь «многие ко многим».
class MultiChoiceFieldSpec extends FieldSpec {
  const MultiChoiceFieldSpec(
    super.key,
    super.label, {
    required this.options,
    this.minSelected = 1,
    this.maxSelected,
    this.emptyMessage,
    this.helper,
  });

  final List<(int, String)> options;
  final int minSelected;
  final int? maxSelected;
  final String? emptyMessage;
  final String? helper;
}

/// Вложенная группа полей — связь «один к одному» (билет у читателя).
class GroupSpec extends FieldSpec {
  const GroupSpec(super.key, super.label, this.children, {this.icon});
  final List<FieldSpec> children;
  final IconData? icon;
}

/// Текущие значения формы — для перекрёстных проверок и каскадных списков.
class FormValues {
  FormValues(this._text, this._choice, this._multi);

  final String Function(String key) _text;
  final Object? Function(String key) _choice;
  final List<int> Function(String key) _multi;

  String text(String key) => _text(key).trim();
  int? intValue(String key) => int.tryParse(text(key));
  Object? choice(String key) => _choice(key);
  List<int> multi(String key) => _multi(key);
}

/// Обработчик отправки: сохраняет запись и возвращает ошибки по полям
/// (например, нарушение уникальности). Пустой результат — успех.
typedef SubmitHandler = Future<Map<String, String>> Function(FormValues values);

// ---------------------------------------------------------------- виджет

/// Общая форма создания и редактирования записи. Отвечает за разметку,
/// проверку всех полей, отправку, вывод ошибок под полями и предупреждение
/// о несохранённых изменениях.
class EntityForm extends StatefulWidget {
  const EntityForm({
    super.key,
    required this.initialValues,
    required this.buildFields,
    required this.onSubmit,
    required this.onCancel,
    required this.isEditing,
  });

  /// Начальные значения: String для текстовых полей, Object? для выбора,
  /// List<int> для множественного выбора.
  final Map<String, Object?> initialValues;

  /// Список полей строится заново при каждом изменении выбора — так
  /// реализуются каскадные списки.
  final List<FieldSpec> Function(FormValues values) buildFields;
  final SubmitHandler onSubmit;
  final VoidCallback onCancel;
  final bool isEditing;

  @override
  State<EntityForm> createState() => _EntityFormState();
}

class _EntityFormState extends State<EntityForm> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, TextEditingController> _controllers = {};
  late final Map<String, Object?> _choices = {
    for (final e in widget.initialValues.entries)
      if (e.value is! String && e.value is! List) e.key: e.value,
  };
  late final Map<String, List<int>> _multi = {
    for (final e in widget.initialValues.entries)
      if (e.value is List) e.key: List<int>.from(e.value! as List),
  };

  /// Ошибки, пришедшие после отправки (уникальность). Показываются
  /// в своём поле через его validator.
  final Map<String, String> _externalErrors = {};
  late final UnsavedChangesGuard _guard;
  bool _dirty = false;
  bool _submitted = false;
  bool _saving = false;

  late final FormValues _values = FormValues(
    (key) => _controller(key).text,
    (key) => _choices[key],
    (key) => _multi[key] ?? const [],
  );

  @override
  void initState() {
    super.initState();
    _guard = context.read<UnsavedChangesGuard>()..dirty = false;
  }

  TextEditingController _controller(String key) =>
      _controllers.putIfAbsent(key, () {
        final initial = widget.initialValues[key];
        // Контроллер получает начальный текст сам: одновременно задавать
        // controller и initialValue у TextFormField нельзя.
        return TextEditingController(text: initial is String ? initial : '')
          ..addListener(_markDirty);
      });

  void _markDirty() {
    _guard.dirty = true;
    if (!_dirty) setState(() => _dirty = true);
  }

  @override
  void dispose() {
    _guard.dirty = false;
    for (final c in _controllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() {
      _submitted = true;
      _externalErrors.clear();
    });
    if (!_formKey.currentState!.validate()) return;

    final messenger = ScaffoldMessenger.of(context);
    setState(() => _saving = true);
    // Обработчик при успехе сам уводит с экрана — это не должно
    // считаться уходом с несохранёнными изменениями.
    _guard.dirty = false;
    try {
      final errors = await widget.onSubmit(_values);
      if (!mounted) return;
      if (errors.isNotEmpty) {
        _guard.dirty = _dirty;
        setState(() => _externalErrors.addAll(errors));
        _formKey.currentState!.validate();
      }
    } on ValidationException catch (e) {
      // 422: сервер вернул ошибки по полям — показываем их под полями.
      if (!mounted) return;
      _guard.dirty = _dirty;
      setState(() => _externalErrors.addAll(e.errors));
      _formKey.currentState!.validate();
      if (e.errors.isEmpty) {
        messenger.showSnackBar(SnackBar(content: Text(e.message)));
      }
    } catch (e) {
      // 409, 403, сеть и прочее — понятным сообщением.
      _guard.dirty = _dirty;
      if (mounted) {
        await showApiError(context, e,
            prefix: 'Не удалось сохранить', messenger: messenger);
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _onPopBlocked() async {
    final leave = await confirmLeave(context);
    if (!leave || !mounted) return;
    _guard.dirty = false;
    setState(() => _dirty = false);
    widget.onCancel();
  }

  @override
  Widget build(BuildContext context) {
    final fields = widget.buildFields(_values);
    return PopScope(
      canPop: !_dirty,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _onPopBlocked();
      },
      child: Form(
        key: _formKey,
        autovalidateMode: _submitted
            ? AutovalidateMode.onUserInteraction
            : AutovalidateMode.disabled,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Align(
            alignment: Alignment.topLeft,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 760),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _layout(fields),
                  const SizedBox(height: 24),
                  Wrap(
                    spacing: 12,
                    runSpacing: 8,
                    children: [
                      FilledButton.icon(
                        onPressed: _saving ? null : _submit,
                        icon: _saving
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.save),
                        label: Text(widget.isEditing ? 'Сохранить изменения' : 'Создать'),
                      ),
                      OutlinedButton(
                        onPressed: _saving ? null : widget.onCancel,
                        child: const Text('Отмена'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _layout(List<FieldSpec> fields) => Wrap(
        spacing: 16,
        runSpacing: 20,
        children: [for (final f in fields) _field(f)],
      );

  Widget _field(FieldSpec spec) => switch (spec) {
        TextFieldSpec s => SizedBox(
            width: s.width ?? double.infinity,
            child: _text(s),
          ),
        ChoiceFieldSpec s => SizedBox(
            width: s.width ?? double.infinity,
            child: _choice(s),
          ),
        MultiChoiceFieldSpec s =>
          SizedBox(width: double.infinity, child: _multiChoice(s)),
        GroupSpec s => SizedBox(width: double.infinity, child: _group(s)),
      };

  String? _external(String key) => _externalErrors[key];

  Widget _text(TextFieldSpec spec) => TextFormField(
        controller: _controller(spec.key),
        keyboardType: spec.numeric ? TextInputType.number : TextInputType.text,
        inputFormatters: [
          if (spec.numeric) FilteringTextInputFormatter.digitsOnly,
        ],
        maxLines: spec.maxLines,
        readOnly: spec.readOnly,
        decoration: InputDecoration(
          filled: spec.readOnly,
          labelText: spec.label,
          hintText: spec.hint,
          helperText: spec.helper,
          // Узкое поле: сообщение переносится, а не обрезается.
          helperMaxLines: 2,
          errorMaxLines: 3,
          border: const OutlineInputBorder(),
        ),
        validator: (v) => _external(spec.key) ?? spec.validator?.call(v),
        onChanged: (_) {
          if (_externalErrors.remove(spec.key) != null) setState(() {});
        },
      );

  Widget _choice(ChoiceFieldSpec spec) {
    final current = _choices[spec.key];
    final effective =
        spec.options.any((o) => o.$1 == current) ? current : null;
    return DropdownButtonFormField<Object>(
      initialValue: effective,
      isExpanded: true,
      decoration: InputDecoration(
        labelText: spec.label,
        helperText: spec.helper,
        helperMaxLines: 2,
        errorMaxLines: 2,
        border: const OutlineInputBorder(),
      ),
      items: [
        for (final o in spec.options)
          DropdownMenuItem<Object>(
            value: o.$1,
            child: Text(o.$2, overflow: TextOverflow.ellipsis),
          ),
      ],
      onChanged: (value) {
        setState(() => _choices[spec.key] = value);
        _markDirty();
      },
      validator: (value) =>
          _external(spec.key) ?? (value == null ? spec.requiredMessage : null),
    );
  }

  Widget _multiChoice(MultiChoiceFieldSpec spec) {
    final available = {for (final o in spec.options) o.$1};
    return FormField<List<int>>(
      key: ValueKey('multi-${spec.key}'),
      initialValue: _multi[spec.key] ?? const [],
      validator: (value) {
        final external = _external(spec.key);
        if (external != null) return external;
        final selected = (value ?? const []).where(available.contains).length;
        if (selected < spec.minSelected) {
          return spec.emptyMessage ?? 'Выберите хотя бы одно значение';
        }
        final max = spec.maxSelected;
        if (max != null && selected > max) return 'Не больше $max';
        return null;
      },
      builder: (field) {
        final value = field.value ?? const <int>[];
        return InputDecorator(
          decoration: InputDecoration(
            labelText: spec.label,
            helperText: spec.helper,
            helperMaxLines: 2,
            border: const OutlineInputBorder(),
            // Ошибка выводится так же, как у обычного поля, — под ним.
            errorText: field.errorText,
            errorMaxLines: 2,
          ),
          child: spec.options.isEmpty
              ? const Text('Нет доступных значений')
              : Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final o in spec.options)
                      FilterChip(
                        label: Text(o.$2),
                        selected: value.contains(o.$1),
                        onSelected: (_) {
                          final next = [...value];
                          if (!next.remove(o.$1)) next.add(o.$1);
                          // Без didChange форма не узнает о новом значении.
                          field.didChange(next);
                          setState(() => _multi[spec.key] = next);
                          _markDirty();
                        },
                      ),
                  ],
                ),
        );
      },
    );
  }

  Widget _group(GroupSpec spec) {
    final scheme = Theme.of(context).colorScheme;
    final icon = spec.icon;
    return DecoratedBox(
      decoration: BoxDecoration(
        color: scheme.surfaceContainerLow,
        border: Border.all(color: scheme.outlineVariant),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                if (icon != null) ...[Icon(icon, size: 20), const SizedBox(width: 8)],
                Text(spec.label, style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 16),
            _layout(spec.children),
          ],
        ),
      ),
    );
  }
}

/// Подтверждение ухода с формы с несохранёнными изменениями.
Future<bool> confirmLeave(BuildContext context) => confirmAction(
      context,
      title: 'Уйти без сохранения?',
      message: 'В форме есть несохранённые изменения. Если уйти, они будут потеряны.',
      confirmLabel: 'Уйти без сохранения',
    );

/// Страница формы: один экран и для создания, и для изменения записи.
/// При изменении сначала дожидается загрузки записи ([DetailsNotifier]),
/// и только потом строит форму — иначе поля открылись бы пустыми.
class EntityFormPage<T> extends StatelessWidget {
  const EntityFormPage({
    super.key,
    required this.title,
    required this.backLocation,
    required this.isEditing,
    required this.formBuilder,
  });

  final String title;
  final String backLocation;
  final bool isEditing;
  final Widget Function(BuildContext context, T? entity) formBuilder;

  @override
  Widget build(BuildContext context) {
    final Widget body;
    if (isEditing) {
      final details = context.watch<DetailsNotifier<T>>();
      final data = details.data;
      body = DetailsStateView(
        status: details.status,
        error: details.error,
        notFound: details.notFound,
        hasData: data != null,
        notFoundMessage: 'Запись для изменения не найдена.',
        onRetry: details.load,
        builder: () => formBuilder(context, data),
      );
    } else {
      body = formBuilder(context, null);
    }
    return Scaffold(
      appBar: AppBar(
        // Переход назад проходит через onExit маршрута: при несохранённых
        // изменениях будет задан вопрос.
        leading: BackButton(onPressed: () => context.go(backLocation)),
        title: Text(title),
      ),
      body: body,
    );
  }
}
