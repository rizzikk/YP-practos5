import 'json_utils.dart';

/// Жанр. Поля соответствуют контракту учебного API.
class Genre {
  final int id;
  final String name;
  final String description;
  final DateTime? deletedAt;

  const Genre({
    required this.id,
    required this.name,
    this.description = '',
    this.deletedAt,
  });

  bool get isDeleted => deletedAt != null;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'deletedAt': deletedAt?.toIso8601String(),
      };

  Map<String, dynamic> toInput() => {'name': name, 'description': description};

  factory Genre.fromJson(Map<String, dynamic> json) => Genre(
        id: readInt(json['id']),
        name: readString(json['name']),
        description: readString(json['description']),
        deletedAt: readDate(json['deletedAt']),
      );
}
