import 'json_utils.dart';

/// Читательский билет. Один к одному с читателем: приходит вложенным
/// объектом в ответе о читателе, выдаётся библиотекой (на сервере).
class LibraryCard {
  final int? id;
  final String number;
  final DateTime issuedAt;
  final DateTime expiresAt;

  const LibraryCard({
    this.id,
    required this.number,
    required this.issuedAt,
    required this.expiresAt,
  });

  bool isExpiredAt(DateTime now) => expiresAt.isBefore(now);
  bool get isExpired => isExpiredAt(DateTime.now());

  Map<String, dynamic> toJson() => {
        'id': id,
        'number': number,
        'issuedAt': issuedAt.toIso8601String(),
        'expiresAt': expiresAt.toIso8601String(),
      };

  factory LibraryCard.fromJson(Map<String, dynamic> json) {
    final issued = readDate(json['issuedAt']) ?? DateTime(2000);
    return LibraryCard(
      id: readIntOrNull(json['id']),
      number: readString(json['number']),
      issuedAt: issued,
      expiresAt: readDate(json['expiresAt']) ?? issued,
    );
  }
}

/// Читатель. Поля соответствуют контракту учебного API.
class Reader {
  final int id;
  final String fullName;
  final String email;
  final String? phone;
  final LibraryCard? card;
  final DateTime? deletedAt;

  const Reader({
    required this.id,
    required this.fullName,
    required this.email,
    this.phone,
    this.card,
    this.deletedAt,
  });

  bool get isDeleted => deletedAt != null;

  Map<String, dynamic> toJson() => {
        'id': id,
        'fullName': fullName,
        'email': email,
        'phone': phone,
        'card': card?.toJson(),
        'deletedAt': deletedAt?.toIso8601String(),
      };

  /// Билет на запись не передаётся: его оформляет сервер.
  Map<String, dynamic> toInput() =>
      {'fullName': fullName, 'email': email, 'phone': phone ?? ''};

  factory Reader.fromJson(Map<String, dynamic> json) {
    final phone = readStringOrNull(json['phone']);
    final card = json['card'];
    return Reader(
      id: readInt(json['id']),
      fullName: readString(json['fullName']),
      email: readString(json['email']),
      phone: phone == null || phone.isEmpty ? null : phone,
      card: card is Map ? LibraryCard.fromJson(readMap(card)) : null,
      deletedAt: readDate(json['deletedAt']),
    );
  }
}
