import 'query_params.dart';

/// Условия отбора для «простых» списков: жанров, издательств, читателей.
/// Помимо поиска, сортировки и страниц поддерживает один фильтр, имя
/// параметра которого в адресе задаётся [filterParam] (city, status, kind).
class ListQuery {
  final String search;
  final String? filter;
  final String filterParam;
  final String sortField;
  final String defaultSort;
  final bool sortAscending;
  final int page;
  final int size;
  final bool includeDeleted;

  const ListQuery({
    required this.defaultSort,
    this.filterParam = 'filter',
    this.search = '',
    this.filter,
    String? sortField,
    this.sortAscending = true,
    this.page = 1,
    this.size = defaultPageSize,
    this.includeDeleted = false,
  }) : sortField = sortField ?? defaultSort;

  factory ListQuery.fromQueryParameters(
    Map<String, String> p, {
    required Set<String> sortFields,
    required String defaultSort,
    String filterParam = 'filter',
  }) {
    final sort =
        parseSort(p['sort'], allowed: sortFields, fallback: defaultSort);
    final filter = (p[filterParam] ?? '').trim();
    return ListQuery(
      defaultSort: defaultSort,
      filterParam: filterParam,
      search: (p['search'] ?? '').trim(),
      filter: filter.isEmpty ? null : filter,
      sortField: sort.field,
      sortAscending: sort.ascending,
      page: parsePage(p['page']),
      size: parseSize(p['size']),
      includeDeleted: parseBoolParam(p['deleted']),
    );
  }

  Map<String, String> toQueryParameters() => {
        if (search.isNotEmpty) 'search': search,
        if (filter != null) filterParam: filter!,
        if (sortField != defaultSort || !sortAscending)
          'sort': formatSort(sortField, sortAscending),
        if (page != 1) 'page': '$page',
        if (size != defaultPageSize) 'size': '$size',
        if (includeDeleted) 'deleted': '1',
      };

  bool get hasFilters => search.isNotEmpty || filter != null || includeDeleted;

  int get activeFilterCount =>
      [filter != null, includeDeleted].where((x) => x).length;

  ListQuery clearFilters() => ListQuery(
        defaultSort: defaultSort,
        filterParam: filterParam,
        sortField: sortField,
        sortAscending: sortAscending,
        size: size,
      );

  ListQuery copyWith({
    String? search,
    Object? filter = _unset,
    String? sortField,
    bool? sortAscending,
    int? page,
    int? size,
    bool? includeDeleted,
  }) =>
      ListQuery(
        defaultSort: defaultSort,
        filterParam: filterParam,
        search: search ?? this.search,
        filter: filter == _unset ? this.filter : filter as String?,
        sortField: sortField ?? this.sortField,
        sortAscending: sortAscending ?? this.sortAscending,
        // Любое изменение условий отбора возвращает на первую страницу
        page: page ?? 1,
        size: size ?? this.size,
        includeDeleted: includeDeleted ?? this.includeDeleted,
      );

  static const _unset = Object();

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ListQuery &&
          search == other.search &&
          filter == other.filter &&
          filterParam == other.filterParam &&
          sortField == other.sortField &&
          defaultSort == other.defaultSort &&
          sortAscending == other.sortAscending &&
          page == other.page &&
          size == other.size &&
          includeDeleted == other.includeDeleted;

  @override
  int get hashCode => Object.hash(search, filter, filterParam, sortField,
      defaultSort, sortAscending, page, size, includeDeleted);
}
