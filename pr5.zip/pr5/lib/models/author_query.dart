import 'query_params.dart';

/// Условия отбора списка авторов.
class AuthorQuery {
  static const Set<String> sortFields = {'fullName', 'country', 'birthYear'};
  static const String defaultSortField = 'fullName';

  final String search;
  final String? country;
  final String sortField;
  final bool sortAscending;
  final int page;
  final int size;
  final bool includeDeleted;

  const AuthorQuery({
    this.search = '',
    this.country,
    this.sortField = defaultSortField,
    this.sortAscending = true,
    this.page = 1,
    this.size = defaultPageSize,
    this.includeDeleted = false,
  });

  factory AuthorQuery.fromQueryParameters(Map<String, String> p) {
    final sort =
        parseSort(p['sort'], allowed: sortFields, fallback: defaultSortField);
    final country = (p['country'] ?? '').trim();
    return AuthorQuery(
      search: (p['search'] ?? '').trim(),
      country: country.isEmpty ? null : country,
      sortField: sort.field,
      sortAscending: sort.ascending,
      page: parsePage(p['page']),
      size: parseSize(p['size']),
      includeDeleted: parseBoolParam(p['deleted']),
    );
  }

  Map<String, String> toQueryParameters() => {
        if (search.isNotEmpty) 'search': search,
        if (country != null) 'country': country!,
        if (sortField != defaultSortField || !sortAscending)
          'sort': formatSort(sortField, sortAscending),
        if (page != 1) 'page': '$page',
        if (size != defaultPageSize) 'size': '$size',
        if (includeDeleted) 'deleted': '1',
      };

  bool get hasFilters => search.isNotEmpty || country != null || includeDeleted;

  int get activeFilterCount =>
      [country != null, includeDeleted].where((x) => x).length;

  AuthorQuery clearFilters() => AuthorQuery(
        sortField: sortField,
        sortAscending: sortAscending,
        size: size,
      );

  AuthorQuery copyWith({
    String? search,
    Object? country = _unset,
    String? sortField,
    bool? sortAscending,
    int? page,
    int? size,
    bool? includeDeleted,
  }) {
    return AuthorQuery(
      search: search ?? this.search,
      country: country == _unset ? this.country : country as String?,
      sortField: sortField ?? this.sortField,
      sortAscending: sortAscending ?? this.sortAscending,
      // Любое изменение условий отбора возвращает на первую страницу
      page: page ?? 1,
      size: size ?? this.size,
      includeDeleted: includeDeleted ?? this.includeDeleted,
    );
  }

  static const _unset = Object();

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AuthorQuery &&
          search == other.search &&
          country == other.country &&
          sortField == other.sortField &&
          sortAscending == other.sortAscending &&
          page == other.page &&
          size == other.size &&
          includeDeleted == other.includeDeleted;

  @override
  int get hashCode => Object.hash(search, country, sortField, sortAscending,
      page, size, includeDeleted);
}
