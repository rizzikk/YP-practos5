import 'json_utils.dart';

/// Автор. Поля соответствуют контракту учебного API (раздел 4).
class Author {
  final int id;

  /// Фамилия и инициалы: «Толстой Л. Н.».
  final String fullName;
  final int? birthYear;
  final String country;
  final DateTime? deletedAt;

  const Author({
    required this.id,
    required this.fullName,
    this.birthYear,
    this.country = '',
    this.deletedAt,
  });

  bool get isDeleted => deletedAt != null;

  /// Краткое имя для списков книг.
  String get shortName => fullName;

  String get lifeYears => birthYear == null ? '—' : 'род. $birthYear';

  Author copyWith({
    String? fullName,
    int? birthYear,
    String? country,
    DateTime? deletedAt,
    bool clearDeletedAt = false,
  }) =>
      Author(
        id: id,
        fullName: fullName ?? this.fullName,
        birthYear: birthYear ?? this.birthYear,
        country: country ?? this.country,
        deletedAt: clearDeletedAt ? null : (deletedAt ?? this.deletedAt),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'fullName': fullName,
        'birthYear': birthYear,
        'country': country,
        'deletedAt': deletedAt?.toIso8601String(),
      };

  Map<String, dynamic> toInput() =>
      {'fullName': fullName, 'birthYear': birthYear, 'country': country};

  factory Author.fromJson(Map<String, dynamic> json) => Author(
        id: readInt(json['id']),
        fullName: readString(json['fullName']),
        birthYear: readIntOrNull(json['birthYear']),
        country: readString(json['country']),
        deletedAt: readDate(json['deletedAt']),
      );
}
