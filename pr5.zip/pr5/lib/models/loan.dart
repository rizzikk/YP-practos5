import 'json_utils.dart';

/// Выдача книги читателю.
class Loan {
  final int id;
  final int readerId;
  final String readerName;
  final int bookId;
  final String bookTitle;
  final DateTime? issuedAt;
  final DateTime? dueAt;
  final DateTime? returnedAt;
  final String status;

  const Loan({
    required this.id,
    required this.readerId,
    required this.readerName,
    required this.bookId,
    required this.bookTitle,
    this.issuedAt,
    this.dueAt,
    this.returnedAt,
    this.status = 'active',
  });

  factory Loan.fromJson(Map<String, dynamic> json) {
    final reader = readMap(json['reader']);
    final book = readMap(json['book']);
    return Loan(
      id: readInt(json['id']),
      readerId: readInt(reader['id']),
      readerName: readString(reader['fullName']),
      bookId: readInt(book['id']),
      bookTitle: readString(book['title']),
      issuedAt: readDate(json['issuedAt']),
      dueAt: readDate(json['dueAt']),
      returnedAt: readDate(json['returnedAt']),
      status: readString(json['status'], 'active'),
    );
  }
}
