import 'package:flutter/material.dart';

import '../models/reader.dart';

/// Выбор читателя и срока выдачи. Возвращает (readerId, days) или null.
class IssueLoanDialog extends StatefulWidget {
  const IssueLoanDialog({super.key, required this.bookTitle, required this.readers});

  final String bookTitle;
  final Future<List<Reader>> readers;

  @override
  State<IssueLoanDialog> createState() => _IssueLoanDialogState();
}

class _IssueLoanDialogState extends State<IssueLoanDialog> {
  int? _readerId;
  int _days = 14;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Выдать книгу'),
      content: SizedBox(
        width: 420,
        child: FutureBuilder<List<Reader>>(
          future: widget.readers,
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Text('Не удалось загрузить читателей: ${snapshot.error}');
            }
            final readers = snapshot.data;
            if (readers == null) {
              return const SizedBox(
                  height: 80, child: Center(child: CircularProgressIndicator()));
            }
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text('«${widget.bookTitle}»'),
                const SizedBox(height: 16),
                DropdownButtonFormField<int>(
                  initialValue: _readerId,
                  isExpanded: true,
                  decoration: const InputDecoration(
                      labelText: 'Читатель', border: OutlineInputBorder()),
                  items: [
                    for (final r in readers)
                      DropdownMenuItem(value: r.id, child: Text(r.fullName)),
                  ],
                  onChanged: (v) => setState(() => _readerId = v),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<int>(
                  initialValue: _days,
                  decoration: const InputDecoration(
                      labelText: 'Срок', border: OutlineInputBorder()),
                  items: const [
                    DropdownMenuItem(value: 7, child: Text('7 дней')),
                    DropdownMenuItem(value: 14, child: Text('14 дней')),
                    DropdownMenuItem(value: 30, child: Text('30 дней')),
                  ],
                  onChanged: (v) => setState(() => _days = v ?? 14),
                ),
              ],
            );
          },
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Отмена'),
        ),
        FilledButton(
          onPressed: _readerId == null
              ? null
              : () => Navigator.of(context).pop((_readerId!, _days)),
          child: const Text('Выдать'),
        ),
      ],
    );
  }
}
