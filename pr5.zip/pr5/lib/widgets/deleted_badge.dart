import 'package:flutter/material.dart';

/// Метка «удалено» у логически удалённой записи.
class DeletedBadge extends StatelessWidget {
  const DeletedBadge({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: scheme.errorContainer,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        'удалено',
        style: Theme.of(context)
            .textTheme
            .labelSmall
            ?.copyWith(color: scheme.onErrorContainer),
      ),
    );
  }
}

/// Название записи с меткой «удалено» при необходимости.
class TitleWithBadge extends StatelessWidget {
  final String text;
  final bool deleted;

  const TitleWithBadge({super.key, required this.text, required this.deleted});

  @override
  Widget build(BuildContext context) => Wrap(
        spacing: 6,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [Text(text), if (deleted) const DeletedBadge()],
      );
}
