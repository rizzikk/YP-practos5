import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../auth/auth_notifier.dart';
import '../auth/permissions.dart';
import 'deleted_badge.dart';

/// Строка карточки «подпись — значение».
class DetailField extends StatelessWidget {
  final String label;
  final Widget child;

  const DetailField({super.key, required this.label, required this.child});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140,
            child: Text(
              label,
              style: theme.textTheme.bodyMedium
                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
          ),
          Expanded(child: child),
        ],
      ),
    );
  }
}

/// Плашка «запись удалена» в карточке.
class DeletedNotice extends StatelessWidget {
  final String text;

  const DeletedNotice({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: scheme.errorContainer,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(Icons.delete_outline, color: scheme.onErrorContainer),
          const SizedBox(width: 8),
          Expanded(
            child: Text(text, style: TextStyle(color: scheme.onErrorContainer)),
          ),
        ],
      ),
    );
  }
}

/// Кнопки карточки записи: изменить, удалить или восстановить, удалить
/// навсегда. Показываются только те, что разрешены роли.
class DetailsActionsBar extends StatelessWidget {
  final bool isDeleted;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onRestore;
  final VoidCallback onHardDelete;

  /// Право на изменение и логическое удаление этой записи.
  final Permission editPermission;

  const DetailsActionsBar({
    super.key,
    required this.isDeleted,
    required this.onEdit,
    required this.onDelete,
    required this.onRestore,
    required this.onHardDelete,
    this.editPermission = Permission.editCatalog,
  });

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthNotifier>();
    final canEdit = auth.has(editPermission);
    final error = Theme.of(context).colorScheme.error;
    return Wrap(
      spacing: 12,
      runSpacing: 8,
      children: [
        if (!isDeleted && canEdit)
          FilledButton.icon(
            onPressed: onEdit,
            icon: const Icon(Icons.edit_outlined),
            label: const Text('Изменить'),
          ),
        if (isDeleted && auth.has(Permission.restore))
          FilledButton.icon(
            onPressed: onRestore,
            icon: const Icon(Icons.restore_from_trash),
            label: const Text('Восстановить'),
          ),
        if (!isDeleted && canEdit)
          OutlinedButton.icon(
            onPressed: onDelete,
            icon: const Icon(Icons.delete_outline),
            label: const Text('Удалить'),
          ),
        if (auth.has(Permission.hardDelete))
          TextButton.icon(
            style: TextButton.styleFrom(foregroundColor: error),
            onPressed: onHardDelete,
            icon: const Icon(Icons.delete_forever),
            label: const Text('Удалить навсегда'),
          ),
      ],
    );
  }
}

/// Список связанных записей в карточке (книги жанра, книги издательства).
class RelatedList extends StatelessWidget {
  final String title;
  final String emptyText;
  final List<(String title, String subtitle, bool deleted, VoidCallback onTap)> items;

  const RelatedList({
    super.key,
    required this.title,
    required this.emptyText,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$title (${items.length})',
            style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        if (items.isEmpty)
          Text(emptyText)
        else
          Card(
            margin: EdgeInsets.zero,
            child: Column(
              children: [
                for (final item in items)
                  ListTile(
                    leading: const Icon(Icons.menu_book),
                    title: Wrap(
                      spacing: 6,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Text(item.$1),
                        if (item.$3) const DeletedBadge(),
                      ],
                    ),
                    subtitle: Text(item.$2),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: item.$4,
                  ),
              ],
            ),
          ),
      ],
    );
  }
}
