/// Параметры сборки. Адрес сервера не зашит в код: он передаётся ключом
/// `--dart-define=API_BASE_URL=...` (на занятии, дома и при публикации разный).
library;

import 'package:flutter/foundation.dart';

const apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://localhost:8080/api',
);

/// Сколько раз повторять чтение при сетевом сбое.
const maxReadAttempts = 3;

/// Журнал запросов в консоли браузера: в отладочной сборке всегда,
/// в релизной — если собрать с `--dart-define=API_LOG=true`.
const apiLog = bool.fromEnvironment('API_LOG', defaultValue: kDebugMode);

/// Правила сессии. Значения по умолчанию — из задания; для проверки их можно
/// уменьшить при сборке, например `--dart-define=IDLE_TIMEOUT_SEC=60`.
class SessionPolicy {
  const SessionPolicy({
    required this.idleTimeout,
    required this.idleWarning,
    required this.maxDuration,
  });

  /// Выход после этого времени без действий пользователя.
  final Duration idleTimeout;

  /// За сколько до выхода по неактивности показать предупреждение.
  final Duration idleWarning;

  /// Предельная длительность сессии независимо от активности.
  final Duration maxDuration;

  static const fromEnvironment = SessionPolicy(
    idleTimeout: Duration(
        seconds: int.fromEnvironment('IDLE_TIMEOUT_SEC', defaultValue: 180)),
    idleWarning: Duration(
        seconds: int.fromEnvironment('IDLE_WARNING_SEC', defaultValue: 30)),
    maxDuration: Duration(
        minutes: int.fromEnvironment('SESSION_MAX_MIN', defaultValue: 60)),
  );
}
