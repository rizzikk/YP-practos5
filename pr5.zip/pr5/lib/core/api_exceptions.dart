import 'package:dio/dio.dart';

/// Исключения предметной области. Виджеты и состояние знают только о них,
/// а не о Dio: сетевой слой можно заменить, не трогая экраны.
sealed class ApiException implements Exception {
  const ApiException(this.message);
  final String message;

  @override
  String toString() => message;
}

/// Нет соединения, таймаут, сервер недоступен, заблокировано CORS.
class NetworkException extends ApiException {
  const NetworkException(
      [super.message = 'Сервер недоступен. Проверьте соединение.']);
}

/// Запрос отменён, потому что условия отбора успели смениться.
class CancelledException extends ApiException {
  const CancelledException() : super('Запрос отменён');
}

/// 400 — некорректный запрос.
class BadRequestException extends ApiException {
  const BadRequestException([super.message = 'Некорректный запрос.']);
}

/// 401 — не аутентифицирован либо срок действия токена истёк.
class UnauthorizedException extends ApiException {
  const UnauthorizedException([super.message = 'Требуется вход в систему.']);
}

/// 403 — роль не позволяет выполнить операцию.
class ForbiddenException extends ApiException {
  const ForbiddenException(
      [super.message = 'Недостаточно прав для этого действия.']);
}

/// 404.
class NotFoundException extends ApiException {
  const NotFoundException([super.message = 'Запись не найдена.']);
}

/// 409 — нарушено ограничение целостности.
class ConflictException extends ApiException {
  const ConflictException(super.message);
}

/// 422 — ошибки валидации по полям. Ключи совпадают с именами полей модели.
class ValidationException extends ApiException {
  const ValidationException(super.message, this.errors);
  final Map<String, String> errors;
}

/// 5xx и всё непредвиденное.
class ServerException extends ApiException {
  const ServerException(
      [super.message = 'Ошибка на сервере. Попробуйте позже.']);
}

/// Код ответа и тело → исключение предметной области.
ApiException mapHttpError(int status, dynamic body) {
  final message = (body is Map && body['message'] is String)
      ? body['message'] as String
      : null;
  return switch (status) {
    400 => BadRequestException(message ?? 'Некорректный запрос.'),
    401 => UnauthorizedException(message ?? 'Требуется вход в систему.'),
    403 => ForbiddenException(
        message ?? 'Недостаточно прав для этого действия.'),
    404 => NotFoundException(message ?? 'Запись не найдена.'),
    409 => ConflictException(message ?? 'Операция невозможна.'),
    422 => ValidationException(
        message ?? 'Ошибка валидации',
        (body is Map && body['errors'] is Map)
            ? (body['errors'] as Map).map((k, v) => MapEntry('$k', '$v'))
            : const {},
      ),
    _ => ServerException(
        '${message ?? 'Ошибка на сервере'} (код $status).'),
  };
}

/// Любой сбой Dio → исключение предметной области.
ApiException mapDioError(DioException e) {
  // Уже разобрано интерсептором — повторно не разбираем, иначе 422
  // превратился бы в ServerException.
  final existing = e.error;
  if (existing is ApiException) return existing;

  final response = e.response;
  if (e.type == DioExceptionType.badResponse && response != null) {
    return mapHttpError(response.statusCode ?? 0, response.data);
  }
  return switch (e.type) {
    DioExceptionType.connectionTimeout ||
    DioExceptionType.sendTimeout ||
    DioExceptionType.receiveTimeout =>
      const NetworkException('Сервер не ответил вовремя.'),
    DioExceptionType.connectionError => const NetworkException(
        'Не удалось соединиться с сервером. Если сервер запущен, откройте '
        'консоль браузера и проверьте наличие ошибки CORS.',
      ),
    DioExceptionType.cancel => const CancelledException(),
    _ => const NetworkException(
        'Не удалось выполнить запрос. Если сервер запущен, откройте '
        'консоль браузера и проверьте наличие ошибки CORS.',
      ),
  };
}

/// Обёртка каждого обращения к сети: наружу выходят только [ApiException].
Future<T> guard<T>(Future<T> Function() action) async {
  try {
    return await action();
  } on DioException catch (e) {
    throw mapDioError(e);
  }
}
