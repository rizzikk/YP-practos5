import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

import 'api_exceptions.dart';
import 'config.dart';
import 'session.dart';

/// Учебные переключатели сервера (`__delay`, `__fail`), переданные в адресе
/// страницы, добавляются к каждому запросу: так проверяются индикатор
/// загрузки и состояние ошибки без правки кода.
Map<String, String> _debugSwitches() {
  if (!kIsWeb) return const {};
  final p = Uri.base.queryParameters;
  return {
    for (final k in const ['__delay', '__fail'])
      if (p[k] != null) k: p[k]!,
  };
}

Dio buildDio(
  ApiSession session, {
  String baseUrl = apiBaseUrl,
  Duration retryDelay = const Duration(milliseconds: 400),
  void Function(String line)? log,
}) {
  final dio = Dio(
    BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 15),
      headers: {'Content-Type': 'application/json'},
      // Коды 4xx не бросают исключение — их разбирает интерсептор.
      validateStatus: (status) => status != null && status < 500,
    ),
  );
  // Интерсептор добавляется сразу при создании клиента — раньше первого
  // запроса, иначе первый запрос ушёл бы без заголовка Authorization.
  dio.interceptors
      .add(ApiInterceptor(dio, session, retryDelay: retryDelay, log: log));
  return dio;
}

/// Общая обработка запросов: токен, журнал, разбор ошибок, повтор чтения
/// при сетевом сбое, обновление истёкшего токена.
class ApiInterceptor extends Interceptor {
  ApiInterceptor(
    this._dio,
    this._session, {
    this.retryDelay = const Duration(milliseconds: 400),
    void Function(String line)? log,
  }) : _logSink = log;

  final Dio _dio;
  final ApiSession _session;
  final Duration retryDelay;
  final void Function(String line)? _logSink;

  /// Адреса входа, регистрации, обновления и выхода. Ответ 401 на них —
  /// это «неверный пароль» или «токен обновления недействителен», и пытаться
  /// обновлять токен здесь нельзя: получился бы бесконечный цикл.
  static bool isAuthPath(String path) => path.contains('/auth/');

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    options.queryParameters = {...options.queryParameters, ..._debugSwitches()};
    final token = _session.accessToken;
    if (token != null && options.extra['skipAuth'] != true) {
      options.headers['Authorization'] = 'Bearer $token';
      // С каким токеном ушёл запрос — чтобы при 401 понять, не обновил ли
      // его уже параллельный запрос.
      options.extra['token'] = token;
    } else {
      options.headers.remove('Authorization');
    }
    options.extra['startedAt'] ??= DateTime.now().millisecondsSinceEpoch;
    handler.next(options);
  }

  @override
  Future<void> onResponse(
      Response<dynamic> response, ResponseInterceptorHandler handler) async {
    final options = response.requestOptions;
    final status = response.statusCode ?? 0;
    _write(options, status);
    if (status < 400) {
      handler.next(response);
      return;
    }

    // Токен доступа истёк: обновляем его и повторяем исходный запрос —
    // незаметно для пользователя. Повтор только один (флаг retried),
    // и никогда для адресов /auth/.
    final refresh = _session.refresh;
    if (status == 401 &&
        refresh != null &&
        !isAuthPath(options.path) &&
        options.extra['retried'] != true) {
      // Токен уже обновил другой запрос — достаточно повторить этот.
      final current = _session.accessToken;
      final alreadyRefreshed =
          current != null && options.extra['token'] != current;
      if (!alreadyRefreshed) {
        _line('[AUTH] 401 на ${options.method} ${options.path} — обновляю токен');
      }
      if (alreadyRefreshed || await refresh()) {
        options.extra['retried'] = true;
        options.extra['startedAt'] = DateTime.now().millisecondsSinceEpoch;
        _line('[AUTH] токен обновлён, повторяю ${options.method} ${options.path}');
        try {
          // Заголовок с новым токеном подставит onRequest.
          handler.resolve(await _dio.fetch<dynamic>(options));
        } on DioException catch (e) {
          handler.reject(e, true);
        }
        return;
      }
      _line('[AUTH] обновить токен не удалось — выход из системы');
      handler.reject(
        DioException(
          requestOptions: options,
          response: response,
          type: DioExceptionType.badResponse,
          error: const UnauthorizedException(
              'Сессия истекла. Войдите в систему снова.'),
        ),
        true,
      );
      return;
    }

    // throw здесь нельзя: Dio завернёт исключение в DioException(unknown).
    handler.reject(
      DioException(
        requestOptions: options,
        response: response,
        type: DioExceptionType.badResponse,
        error: mapHttpError(status, response.data),
      ),
      true,
    );
  }

  @override
  Future<void> onError(
      DioException err, ErrorInterceptorHandler handler) async {
    final options = err.requestOptions;
    if (err.error is! ApiException) {
      _write(options, err.response?.statusCode, failure: err.type.name);
    }
    if (_isRetryable(err)) {
      final attempt = (options.extra['attempt'] as int? ?? 1);
      if (attempt < maxReadAttempts) {
        // Нарастающая пауза: 400, 800 мс…
        await Future<void>.delayed(retryDelay * (1 << (attempt - 1)));
        options.extra['attempt'] = attempt + 1;
        _line('[API] повтор ${attempt + 1}/$maxReadAttempts '
            '${options.method} ${options.uri}');
        try {
          handler.resolve(await _dio.fetch<dynamic>(options));
        } on DioException catch (e) {
          handler.next(e);
        }
        return;
      }
    }
    handler.next(err);
  }

  /// Повторяется только чтение и только при сетевом сбое: повтор создания
  /// записи мог бы создать её дважды.
  bool _isRetryable(DioException e) {
    if (e.requestOptions.method.toUpperCase() != 'GET') return false;
    if (e.requestOptions.cancelToken?.isCancelled ?? false) return false;
    return switch (e.type) {
      DioExceptionType.connectionError ||
      DioExceptionType.connectionTimeout ||
      DioExceptionType.receiveTimeout =>
        true,
      _ => false,
    };
  }

  void _write(RequestOptions options, int? status, {String? failure}) {
    final started = options.extra['startedAt'] as int?;
    final ms = started == null
        ? ''
        : ' ${DateTime.now().millisecondsSinceEpoch - started} мс';
    _line('[API] ${options.method} ${options.uri} → '
        '${status ?? failure ?? '—'}$ms');
  }

  void _line(String text) {
    final sink = _logSink;
    if (sink != null) {
      sink(text);
    } else if (apiLog) {
      debugPrint(text);
    }
  }
}
