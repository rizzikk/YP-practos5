import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../forms/entity_form.dart';
import '../forms/validators.dart';
import '../models/author.dart';
import '../router/locations.dart';
import '../state/author_list_notifier.dart';

/// Один экран и для нового автора, и для изменения.
class AuthorFormScreen extends StatelessWidget {
  const AuthorFormScreen({super.key, this.id});

  final int? id;

  @override
  Widget build(BuildContext context) {
    final list = context.read<AuthorListNotifier>();
    final back = id == null
        ? authorsLocation(list.query)
        : detailsLocation(authorsPath, id!);
    final year = DateTime.now().year;

    return EntityFormPage<Author>(
      title: id == null ? 'Новый автор' : 'Изменение автора',
      backLocation: back,
      isEditing: id != null,
      formBuilder: (context, a) => EntityForm(
        key: ValueKey('author-${a?.id}'),
        isEditing: a != null,
        initialValues: {
          'fullName': a?.fullName ?? '',
          'country': a?.country ?? '',
          'birthYear': a?.birthYear?.toString() ?? '',
        },
        onCancel: () => context.go(back),
        buildFields: (v) => [
          TextFieldSpec('fullName', 'ФИО',
              hint: 'Толстой Л. Н.',
              validator: Validators.all([
                Validators.required(),
                Validators.length(min: 2, max: 100),
                Validators.letters(),
              ])),
          TextFieldSpec('country', 'Страна',
              width: 300,
              validator: Validators.all([
                Validators.required(),
                Validators.length(min: 2, max: 60),
                Validators.letters(),
              ])),
          TextFieldSpec('birthYear', 'Год рождения',
              numeric: true,
              width: 180,
              helper: 'Необязательно',
              validator: Validators.intRange(1, year)),
        ],
        onSubmit: (v) async {
          final entity = Author(
            id: a?.id ?? 0,
            fullName: v.text('fullName'),
            country: v.text('country'),
            birthYear: v.intValue('birthYear'),
            deletedAt: a?.deletedAt,
          );
          final saved = await list.save(entity, isNew: a == null);
          if (context.mounted) context.go(detailsLocation(authorsPath, saved.id));
          return const {};
        },
      ),
    );
  }
}
