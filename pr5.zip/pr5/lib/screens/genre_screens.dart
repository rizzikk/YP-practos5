import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../forms/entity_form.dart';
import '../forms/validators.dart';
import '../models/book.dart';
import '../models/genre.dart';
import '../models/list_query.dart';
import '../router/locations.dart';
import '../state/details_notifier.dart';
import '../state/list_notifiers.dart';
import '../widgets/deleted_badge.dart';
import '../widgets/detail_field.dart';
import '../widgets/dialogs.dart';
import '../widgets/entity_table.dart';
import '../widgets/state_views.dart';
import 'entity_list_screen.dart';

typedef GenreDetails = ({Genre genre, List<Book> books});

final genreListConfig = ListScreenConfig<Genre>(
  title: 'Жанры',
  basePath: genresPath,
  searchHint: 'Название или описание',
  addLabel: 'Добавить жанр',
  emptyText: 'Жанров пока нет.',
  idOf: (g) => g.id,
  isDeleted: (g) => g.isDeleted,
  nameOf: (g) => g.name,
  columns: (_) => [
    TableColumnSpec(
      label: 'Название',
      sortField: 'name',
      build: (g) => TitleWithBadge(text: g.name, deleted: g.isDeleted),
    ),
    TableColumnSpec(
      label: 'Описание',
      build: (g) => ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Text(g.description, overflow: TextOverflow.ellipsis),
      ),
    ),
  ],
);

class GenresListScreen extends StatelessWidget {
  const GenresListScreen({super.key, required this.query});
  final ListQuery query;

  @override
  Widget build(BuildContext context) =>
      EntityListScreen<Genre, GenreListNotifier>(config: genreListConfig, query: query);
}

class GenreDetailsScreen extends StatelessWidget {
  const GenreDetailsScreen({super.key, required this.id});
  final int id;

  @override
  Widget build(BuildContext context) {
    final details = context.watch<DetailsNotifier<GenreDetails>>();
    final data = details.data;
    final list = context.read<GenreListNotifier>();
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(
            onPressed: () => context.go(listLocation(genresPath, list.query))),
        title: Text(data?.genre.name ?? 'Жанр №$id'),
      ),
      body: DetailsStateView(
        status: details.status,
        error: details.error,
        notFound: details.notFound,
        hasData: data != null,
        notFoundMessage: 'Жанра с номером $id нет.',
        onRetry: details.load,
        builder: () {
          final genre = data!.genre;
          final deletedAt = genre.deletedAt;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Align(
              alignment: Alignment.topLeft,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 760),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (deletedAt != null)
                      DeletedNotice(text: 'Жанр удалён ${formatDateTime(deletedAt)}'),
                    Text(genre.name, style: Theme.of(context).textTheme.headlineSmall),
                    const SizedBox(height: 16),
                    DetailField(
                      label: 'Описание',
                      child: Text(genre.description.isEmpty ? '—' : genre.description),
                    ),
                    const SizedBox(height: 16),
                    RelatedList(
                      title: 'Книги жанра',
                      emptyText: 'Книг этого жанра в каталоге нет.',
                      items: [
                        for (final b in data.books)
                          (
                            b.title,
                            '${b.year} · ${b.pages} стр.',
                            b.isDeleted,
                            () => context.go(detailsLocation(booksPath, b.id)),
                          ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    DetailsActionsBar(
                      isDeleted: genre.isDeleted,
                      onEdit: () => context.go(editLocation(genresPath, id)),
                      onDelete: () => _delete(context, genre, hard: false),
                      onRestore: () async {
                        final ok = await runWithFeedback(
                            context, () => list.restore(id),
                            success: 'Жанр восстановлен');
                        if (ok) await details.load();
                      },
                      onHardDelete: () => _delete(context, genre, hard: true),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _delete(BuildContext context, Genre genre, {required bool hard}) async {
    final list = context.read<GenreListNotifier>();
    final details = context.read<DetailsNotifier<GenreDetails>>();
    final done = await confirmAndDelete(context,
        list: list, id: genre.id, name: genre.name, hard: hard);
    if (!done) return;
    if (hard) {
      if (context.mounted) context.go(listLocation(genresPath, list.query));
    } else {
      await details.load();
    }
  }
}

class GenreFormScreen extends StatelessWidget {
  const GenreFormScreen({super.key, this.id});
  final int? id;

  @override
  Widget build(BuildContext context) {
    final list = context.read<GenreListNotifier>();
    final back = id == null
        ? listLocation(genresPath, list.query)
        : detailsLocation(genresPath, id!);
    return EntityFormPage<Genre>(
      title: id == null ? 'Новый жанр' : 'Изменение жанра',
      backLocation: back,
      isEditing: id != null,
      formBuilder: (context, genre) => EntityForm(
        key: ValueKey('genre-${genre?.id}'),
        isEditing: genre != null,
        initialValues: {
          'name': genre?.name ?? '',
          'description': genre?.description ?? '',
        },
        onCancel: () => context.go(back),
        buildFields: (v) => [
          TextFieldSpec('name', 'Название',
              validator: Validators.all([
                Validators.required(),
                Validators.length(min: 2, max: 50),
              ])),
          TextFieldSpec('description', 'Описание',
              maxLines: 3,
              helper: 'Необязательно, до 500 символов',
              validator: Validators.length(max: 500)),
        ],
        onSubmit: (v) async {
          final entity = Genre(
            id: genre?.id ?? 0,
            name: v.text('name'),
            description: v.text('description'),
            deletedAt: genre?.deletedAt,
          );
          final saved = await list.save(entity, isNew: genre == null);
          if (context.mounted) context.go(detailsLocation(genresPath, saved.id));
          return const {};
        },
      ),
    );
  }
}
