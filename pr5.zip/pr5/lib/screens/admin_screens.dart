import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../auth/app_user.dart';
import '../auth/auth_notifier.dart';
import '../auth/permissions.dart';
import '../core/api_exceptions.dart';
import '../models/book.dart';
import '../models/page_result.dart';
import '../repositories/book_repository.dart';
import '../repositories/loan_repository.dart';
import '../repositories/reader_repository.dart';
import '../repositories/user_repository.dart';
import '../state/list_notifiers.dart';
import '../widgets/dialogs.dart';
import '../widgets/entity_table.dart';
import '../widgets/state_views.dart';

/// Загрузка данных экрана с тремя состояниями: загрузка, ошибка, данные.
/// Ошибка 403 (например, роль подменена в браузере) показывается текстом
/// сервера, а не пустым экраном.
class _Loader<T> extends StatefulWidget {
  const _Loader({required this.load, required this.builder});

  final Future<T> Function(BuildContext context) load;
  final Widget Function(BuildContext context, T data, VoidCallback reload)
      builder;

  @override
  State<_Loader<T>> createState() => _LoaderState<T>();
}

class _LoaderState<T> extends State<_Loader<T>> {
  late Future<T> _future;

  // Загрузка запускается в initState: читать провайдеры внутри build нельзя.
  @override
  void initState() {
    super.initState();
    _future = widget.load(context);
  }

  void _reload() => setState(() => _future = widget.load(context));

  @override
  Widget build(BuildContext context) => FutureBuilder<T>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            final e = snapshot.error;
            final text = e is ForbiddenException
                ? 'Сервер отказал в доступе (код 403): ${e.message}.'
                : 'Не удалось загрузить данные: $e';
            return ErrorView(message: text, onRetry: _reload);
          }
          if (!snapshot.hasData) return const LoadingView();
          return widget.builder(context, snapshot.data as T, _reload);
        },
      );
}

// ---------------------------------------------------------- пользователи

/// «Пользователи» — экран администратора: учётные записи и роли.
class UsersScreen extends StatelessWidget {
  const UsersScreen({super.key});

  Future<void> _changeRole(BuildContext context, AppUser user, Role role,
      VoidCallback reload) async {
    final repo = context.read<UserRepository>();
    final ok = await confirmAction(
      context,
      title: 'Сменить роль?',
      message: '${user.fullName} (${user.username}): '
          '«${user.role.label}» → «${role.label}».',
      confirmLabel: 'Сменить роль',
      destructive: false,
    );
    if (!ok || !context.mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      await repo.changeRole(user.id, role);
      messenger.showSnackBar(
          SnackBar(content: Text('Роль ${user.username}: ${role.label}')));
      reload();
    } on NotFoundException {
      // Учебный сервер реализует только GET /api/users: смены роли
      // в контракте нет, и сервер отвечает 404.
      if (context.mounted) {
        await showMessageDialog(
          context,
          title: 'Сервер не поддерживает смену роли',
          message: 'Запрос PATCH /api/users/${user.id} вернул 404: учебный '
              'сервер умеет только выдавать список пользователей. '
              'Клиентская часть готова и заработает, когда сервер начнёт '
              'принимать этот запрос.',
          icon: Icons.info_outline,
        );
      }
    } catch (e) {
      if (context.mounted) {
        await showApiError(context, e,
            prefix: 'Не удалось сменить роль', messenger: messenger);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = context.watch<AuthNotifier>().user;
    return Scaffold(
      appBar: AppBar(title: const Text('Пользователи')),
      body: _Loader<PageResult<AppUser>>(
        load: (context) => context.read<UserRepository>().find(),
        builder: (context, page, reload) => Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Text(
                'Учётных записей: ${page.total}. Новые пользователи после '
                'регистрации получают роль «${Role.reader.label}».',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
            Expanded(
              child: EntityTable<AppUser>(
                items: page.items,
                idOf: (u) => u.id,
                columns: [
                  TableColumnSpec(label: '№', build: (u) => Text('${u.id}')),
                  TableColumnSpec(label: 'Логин', build: (u) => Text(u.username)),
                  TableColumnSpec(label: 'ФИО', build: (u) => Text(u.fullName)),
                  TableColumnSpec(
                      label: 'Почта',
                      build: (u) => Text(u.email.isEmpty ? '—' : u.email)),
                  TableColumnSpec(
                      label: 'Роль',
                      build: (u) => Chip(
                            label: Text(u.role.label),
                            visualDensity: VisualDensity.compact,
                          )),
                  TableColumnSpec(
                      label: 'Читатель',
                      build: (u) => Text(u.readerId == null ? '—' : '№${u.readerId}')),
                ],
                actions: (u) => [
                  PopupMenuButton<Role>(
                    tooltip: 'Сменить роль',
                    icon: const Icon(Icons.manage_accounts_outlined),
                    // Свою роль администратор не меняет — иначе сам себя
                    // лишит доступа к этому экрану.
                    enabled: u.id != me?.id,
                    onSelected: (role) => _changeRole(context, u, role, reload),
                    itemBuilder: (_) => [
                      for (final r in Role.values)
                        PopupMenuItem(
                          value: r,
                          enabled: r != u.role,
                          child: Text(r.label),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ------------------------------------------------------------ статистика

class _Stats {
  const _Stats({
    required this.books,
    required this.deletedBooks,
    required this.copies,
    required this.copiesAvailable,
    required this.loansActive,
    required this.loansOverdue,
    required this.loansReturned,
    required this.readers,
    required this.usersByRole,
  });

  final int books;
  final int deletedBooks;
  final int copies;
  final int copiesAvailable;
  final int loansActive;
  final int loansOverdue;
  final int loansReturned;
  final int readers;
  final Map<Role, int> usersByRole;
}

/// «Статистика» — экран администратора.
class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  static Future<_Stats> _load(BuildContext context) async {
    final books = context.read<BookRepository>();
    final loans = context.read<LoanRepository>();
    final readers = context.read<ReaderRepository>();
    final users = context.read<UserRepository>();

    final all = await books.findAll();
    final active = all.where((Book b) => !b.isDeleted).toList();
    Future<int> count(String status) async =>
        (await loans.find(LoanQuery(status: status, size: 1))).total;

    final results = await Future.wait([
      count('active'),
      count('overdue'),
      count('returned'),
      readers
          .find(readerListSpec.initialQuery.copyWith(size: 10))
          .then((p) => p.total),
    ]);
    final userPage = await users.find(size: 100);
    final byRole = {for (final r in Role.values) r: 0};
    for (final u in userPage.items) {
      byRole[u.role] = (byRole[u.role] ?? 0) + 1;
    }
    return _Stats(
      books: active.length,
      deletedBooks: all.length - active.length,
      copies: active.fold(0, (s, b) => s + b.copiesTotal),
      copiesAvailable: active.fold(0, (s, b) => s + b.copiesAvailable),
      loansActive: results[0],
      loansOverdue: results[1],
      loansReturned: results[2],
      readers: results[3],
      usersByRole: byRole,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Статистика')),
      body: _Loader<_Stats>(
        load: _load,
        builder: (context, s, reload) => ListView(
          padding: const EdgeInsets.all(24),
          children: [
            Wrap(
              spacing: 16,
              runSpacing: 16,
              children: [
                _StatCard(Icons.menu_book, 'Книг в каталоге', '${s.books}',
                    'ещё ${s.deletedBooks} в корзине'),
                _StatCard(Icons.inventory_2_outlined, 'Экземпляров',
                    '${s.copies}', 'на полках ${s.copiesAvailable}'),
                _StatCard(Icons.swap_horiz, 'Книг на руках',
                    '${s.loansActive + s.loansOverdue}',
                    'из них просрочено ${s.loansOverdue}'),
                _StatCard(Icons.assignment_return_outlined, 'Возвращено',
                    '${s.loansReturned}', 'закрытых выдач'),
                _StatCard(Icons.badge, 'Читателей', '${s.readers}',
                    'с читательским билетом'),
                _StatCard(
                  Icons.manage_accounts,
                  'Пользователей',
                  '${s.usersByRole.values.fold(0, (a, b) => a + b)}',
                  [
                    for (final r in Role.values)
                      '${r.label.toLowerCase()}: ${s.usersByRole[r]}',
                  ].join(', '),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: reload,
                icon: const Icon(Icons.refresh),
                label: const Text('Обновить'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard(this.icon, this.title, this.value, this.note);
  final IconData icon;
  final String title;
  final String value;
  final String note;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SizedBox(
      width: 260,
      child: Card(
        margin: EdgeInsets.zero,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Icon(icon, color: theme.colorScheme.primary),
                const SizedBox(width: 8),
                Expanded(child: Text(title, style: theme.textTheme.titleSmall)),
              ]),
              const SizedBox(height: 10),
              Text(value, style: theme.textTheme.displaySmall),
              const SizedBox(height: 4),
              Text(note, style: theme.textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}
