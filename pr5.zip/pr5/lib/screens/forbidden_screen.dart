import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../auth/auth_notifier.dart';
import '../auth/permissions.dart';
import '../router/locations.dart';
import '../widgets/state_views.dart';

/// Экран отказа. Сюда ведёт redirect маршрута, если у роли нет права
/// открыть адрес — в том числе введённый вручную.
class ForbiddenScreen extends StatelessWidget {
  const ForbiddenScreen({super.key, this.from, this.need});

  /// Адрес, который пытались открыть.
  final String? from;

  /// Имя недостающего права ([Permission.name]).
  final String? need;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthNotifier>();
    final role = auth.user?.role;
    final permission =
        Permission.values.where((p) => p.name == need).firstOrNull;
    final target = from == null ? 'Этот раздел' : 'Адрес $from';
    final needText = permission == null
        ? ''
        : ' Нужно право: «${permission.label.toLowerCase()}».';
    return Scaffold(
      appBar: AppBar(title: const Text('Нет доступа')),
      body: MessageView(
        icon: Icons.lock_outline,
        iconColor: Theme.of(context).colorScheme.error,
        title: 'Доступ запрещён',
        message: '$target недоступен для роли «${role?.label ?? '—'}».$needText',
        action: Wrap(
          spacing: 12,
          runSpacing: 8,
          alignment: WrapAlignment.center,
          children: [
            FilledButton.icon(
              onPressed: () => context.go(homePath),
              icon: const Icon(Icons.home_outlined),
              label: const Text('На главную'),
            ),
            OutlinedButton.icon(
              onPressed: () => auth.logout(),
              icon: const Icon(Icons.switch_account),
              label: const Text('Войти под другой учётной записью'),
            ),
          ],
        ),
      ),
    );
  }
}
