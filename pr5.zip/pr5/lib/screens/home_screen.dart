import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../auth/auth_notifier.dart';
import '../auth/permissions.dart';
import '../router/locations.dart';
import '../router/sections.dart';
import 'app_shell.dart';

/// Главный экран: приветствие, разделы и права текущей роли.
/// Набор плиток у читателя, библиотекаря и администратора разный.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthNotifier>();
    final user = auth.user;
    final theme = Theme.of(context);
    if (user == null) return const SizedBox.shrink();
    final sections =
        sectionsFor(auth).where((s) => s.path != homePath).toList();
    final ends = auth.sessionEndsAt;
    final sessionText = ends == null
        ? ''
        : ' Сессия продлится до ${_time(ends)}; без действий она завершится '
            'через ${auth.policy.idleTimeout.inMinutes} мин.';

    return Scaffold(
      appBar: AppBar(title: const Text('Главная')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text('Здравствуйте, ${user.fullName}!',
              style: theme.textTheme.headlineSmall),
          const SizedBox(height: 6),
          Text(
            'Вы вошли как ${user.role.label.toLowerCase()} '
            '(логин ${user.username}).$sessionText',
            style: theme.textTheme.bodyLarge
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: 24),
          Text('Разделы', style: theme.textTheme.titleMedium),
          const SizedBox(height: 12),
          Wrap(
            spacing: 16,
            runSpacing: 16,
            children: [
              for (final s in sections)
                _SectionTile(
                  section: s,
                  onTap: () => context.go(AppShell.targetOf(context, s)),
                ),
            ],
          ),
          const SizedBox(height: 28),
          Text('Права роли «${user.role.label}»',
              style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          _PermissionList(role: user.role),
        ],
      ),
    );
  }

  static String _time(DateTime d) =>
      '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
}

class _SectionTile extends StatelessWidget {
  const _SectionTile({required this.section, required this.onTap});
  final AppSection section;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SizedBox(
      width: 250,
      height: 112,
      child: Card(
        margin: EdgeInsets.zero,
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(section.icon, size: 30, color: theme.colorScheme.primary),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(section.label, style: theme.textTheme.titleMedium),
                      const SizedBox(height: 4),
                      Text(section.description,
                          style: theme.textTheme.bodySmall),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Все права с отметкой «есть» или «нет» для роли.
class _PermissionList extends StatelessWidget {
  const _PermissionList({required this.role});
  final Role role;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Wrap(
          children: [
            for (final p in Permission.values)
              SizedBox(
                width: 420,
                child: ListTile(
                  dense: true,
                  leading: Icon(
                    can(role, p) ? Icons.check_circle : Icons.block,
                    color: can(role, p) ? Colors.green.shade600 : scheme.outline,
                  ),
                  title: Text(
                    p.label,
                    style: TextStyle(
                      color: can(role, p) ? null : scheme.outline,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
