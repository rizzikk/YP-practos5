import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../auth/auth_notifier.dart';
import '../auth/permissions.dart';
import '../models/book.dart';
import '../models/book_query.dart';
import '../router/locations.dart';
import '../state/book_list_notifier.dart';
import '../state/catalog_notifier.dart';
import '../state/load_status.dart';
import '../widgets/debounced_text_field.dart';
import '../widgets/deleted_badge.dart';
import '../widgets/dialogs.dart';
import '../widgets/entity_table.dart';
import '../widgets/labeled_dropdown.dart';
import '../widgets/pagination_bar.dart';
import '../widgets/selection_bar.dart';
import '../widgets/state_views.dart';

/// Список книг. Условия отбора приходят из адреса ([query]); любое их
/// изменение — это переход на новый адрес, а не правка состояния напрямую.
/// Поэтому ссылку можно отправить коллеге, а «назад» в браузере
/// возвращает предыдущий набор условий.
class BooksListScreen extends StatefulWidget {
  final BookQuery query;

  const BooksListScreen({super.key, required this.query});

  @override
  State<BooksListScreen> createState() => _BooksListScreenState();
}

class _BooksListScreenState extends State<BooksListScreen> {
  // Роль берётся при каждой перестройке: кнопки, недоступные роли,
  // не показываются. Это уборка интерфейса, защищает сервер.
  late AuthNotifier _auth;
  bool get _canEdit => _auth.has(Permission.editCatalog);

  /// Локальное состояние виджета: раскрыта ли панель фильтров на узком окне.
  bool _filtersExpanded = false;

  BookQuery get _q => widget.query;

  @override
  void initState() {
    super.initState();
    // notifyListeners во время построения кадра запрещён — откладываем.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<BookListNotifier>().applyQuery(_q);
    });
  }

  @override
  void didUpdateWidget(BooksListScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.query != widget.query) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.read<BookListNotifier>().syncWithQuery(_q);
      });
    }
  }

  void _go(BookQuery next) {
    if (next == _q) return;
    context.go(booksLocation(next));
  }

  void _sort(String field) => _go(_q.copyWith(
        sortField: field,
        sortAscending: field == _q.sortField ? !_q.sortAscending : true,
      ));

  static int? _parseYear(String text) => text.isEmpty ? null : int.tryParse(text);

  /// После удаления последних записей страницы номер может выйти за пределы —
  /// переходим на последнюю существующую страницу.
  void _fixPageOverflow(BookListNotifier list) {
    final r = list.result;
    if (list.status == LoadStatus.success &&
        r.items.isEmpty &&
        r.total > 0 &&
        list.query.page > r.totalPages) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _go(_q.copyWith(page: r.totalPages));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final list = context.watch<BookListNotifier>();
    _auth = context.watch<AuthNotifier>();
    final catalog = context.watch<CatalogNotifier>();
    final result = list.result;
    final narrow = MediaQuery.sizeOf(context).width < EntityTable.cardBreakpoint;
    _fixPageOverflow(list);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Книги'),
        actions: [
          IconButton(
            tooltip: 'Обновить',
            icon: const Icon(Icons.refresh),
            onPressed: list.load,
          ),
          if (_canEdit)
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: narrow
                  ? IconButton(
                      tooltip: 'Добавить книгу',
                      icon: const Icon(Icons.add),
                      onPressed: () => context.go(newLocation(booksPath)),
                    )
                  : FilledButton.icon(
                      onPressed: () => context.go(newLocation(booksPath)),
                      icon: const Icon(Icons.add),
                      label: const Text('Добавить книгу'),
                    ),
            ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildFilters(catalog, narrow),
          if (_canEdit && list.hasSelection)
            SelectionBar(
              count: list.selected.length,
              onDelete: () => _deleteSelected(list),
              onClear: list.clearSelection,
            ),
          Expanded(
            child: ListStateView(
              status: list.status,
              error: list.error,
              hasData: result.items.isNotEmpty,
              emptyTitle: _q.hasFilters ? 'Ничего не найдено' : 'Каталог пуст',
              emptyMessage: _q.hasFilters
                  ? 'Ни одна книга не подходит под условия отбора. '
                      'Измените запрос или сбросьте фильтры.'
                  : 'В каталоге пока нет ни одной книги.',
              onRetry: list.load,
              onResetFilters: _q.hasFilters ? () => _go(_q.clearFilters()) : null,
              child: _buildTable(list, catalog),
            ),
          ),
          if (list.status != LoadStatus.error && result.total > 0)
            PaginationBar(
              result: result,
              size: _q.size,
              onPage: (page) => _go(_q.copyWith(page: page)),
              onSize: (size) => _go(_q.copyWith(size: size)),
            ),
        ],
      ),
    );
  }

  Widget _buildFilters(CatalogNotifier catalog, bool narrow) {
    final search = DebouncedTextField(
      value: _q.search,
      label: 'Поиск',
      hint: 'Название или ISBN',
      icon: Icons.search,
      width: narrow ? null : 300,
      onChanged: (v) => _go(_q.copyWith(search: v)),
    );

    final filters = <Widget>[
      LabeledDropdown<int>(
        label: 'Жанр',
        anyLabel: 'Все жанры',
        width: narrow ? null : 200,
        value: _q.genreId,
        options: {for (final g in catalog.genres) g.id: g.name},
        onChanged: (v) => _go(_q.copyWith(genreId: v)),
      ),
      LabeledDropdown<int>(
        label: 'Издательство',
        anyLabel: 'Все издательства',
        width: narrow ? null : 200,
        value: _q.publisherId,
        options: {for (final p in catalog.publishers) p.id: p.name},
        onChanged: (v) => _go(_q.copyWith(publisherId: v)),
      ),
      DebouncedTextField(
        value: _q.yearFrom?.toString() ?? '',
        label: 'Год с',
        width: 120,
        digitsOnly: true,
        maxLength: 4,
        onChanged: (v) => _go(_q.copyWith(yearFrom: _parseYear(v))),
      ),
      DebouncedTextField(
        value: _q.yearTo?.toString() ?? '',
        label: 'Год по',
        width: 120,
        digitsOnly: true,
        maxLength: 4,
        onChanged: (v) => _go(_q.copyWith(yearTo: _parseYear(v))),
      ),
      if (_auth.has(Permission.viewDeleted))
        FilterChip(
          label: const Text('Показывать удалённые'),
          selected: _q.includeDeleted,
          onSelected: (v) => _go(_q.copyWith(includeDeleted: v)),
        ),
      if (_q.hasFilters)
        TextButton.icon(
          onPressed: () => _go(_q.clearFilters()),
          icon: const Icon(Icons.filter_alt_off),
          label: const Text('Сбросить'),
        ),
    ];

    if (!narrow) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        child: Wrap(
          spacing: 12,
          runSpacing: 12,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [search, ...filters],
        ),
      );
    }

    final count = _q.activeFilterCount;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(child: search),
              IconButton(
                tooltip: 'Фильтры',
                isSelected: _filtersExpanded,
                icon: Badge(
                  isLabelVisible: count > 0,
                  label: Text('$count'),
                  child: const Icon(Icons.tune),
                ),
                onPressed: () =>
                    setState(() => _filtersExpanded = !_filtersExpanded),
              ),
            ],
          ),
          if (_filtersExpanded)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Wrap(spacing: 8, runSpacing: 8, children: filters),
            ),
        ],
      ),
    );
  }

  Widget _buildTable(BookListNotifier list, CatalogNotifier catalog) {
    final items = list.result.items;
    return EntityTable<Book>(
      items: items,
      idOf: (b) => b.id,
      isInactive: (b) => b.isDeleted,
      selected: list.selected,
      onToggleSelect: _canEdit ? list.toggleSelection : null,
      onSelectAll: _canEdit
          ? (value) => list.setSelection(items.map((b) => b.id), value)
          : null,
      sortField: _q.sortField,
      sortAscending: _q.sortAscending,
      onSort: _sort,
      onOpen: (b) => context.go(bookLocation(b.id)),
      columns: [
        TableColumnSpec(
          label: 'Название',
          sortField: 'title',
          build: (b) => TitleWithBadge(text: b.title, deleted: b.isDeleted),
        ),
        TableColumnSpec(
          label: 'Авторы',
          build: (b) => Text(catalog.authorNames(b.authorIds)),
        ),
        TableColumnSpec(
          label: 'Жанры',
          build: (b) => Text(catalog.genreNames(b.genreIds)),
        ),
        TableColumnSpec(
          label: 'Издательство',
          build: (b) => Text(catalog.publisherName(b.publisherId)),
        ),
        TableColumnSpec(label: 'ISBN', build: (b) => Text(b.isbn)),
        TableColumnSpec(
          label: 'Год',
          sortField: 'year',
          numeric: true,
          build: (b) => Text('${b.year}'),
        ),
        TableColumnSpec(
          label: 'Страниц',
          sortField: 'pages',
          numeric: true,
          build: (b) => Text('${b.pages}'),
        ),
        TableColumnSpec(
          label: 'В наличии',
          sortField: 'available',
          numeric: true,
          build: (b) => Text('${b.copiesAvailable} из ${b.copiesTotal}'),
        ),
      ],
      actions: _canEdit ||
              _auth.has(Permission.restore) ||
              _auth.has(Permission.hardDelete)
          ? (b) => _rowActions(list, b)
          : null,
    );
  }

  List<Widget> _rowActions(BookListNotifier list, Book b) {
    if (b.isDeleted) {
      return [
        if (_auth.has(Permission.restore))
        IconButton(
          tooltip: 'Восстановить',
          icon: const Icon(Icons.restore_from_trash),
          onPressed: () => runWithFeedback(
            context,
            () => list.restore(b.id),
            success: 'Книга «${b.title}» восстановлена',
          ),
        ),
        if (_auth.has(Permission.hardDelete))
        IconButton(
          tooltip: 'Удалить навсегда',
          icon: Icon(Icons.delete_forever,
              color: Theme.of(context).colorScheme.error),
          onPressed: () => _hardDelete(list, b),
        ),
      ];
    }
    if (!_canEdit) return const [];
    return [
      IconButton(
        tooltip: 'Изменить',
        icon: const Icon(Icons.edit_outlined),
        onPressed: () => context.go(editLocation(booksPath, b.id)),
      ),
      IconButton(
        tooltip: 'Удалить',
        icon: const Icon(Icons.delete_outline),
        onPressed: () => _softDelete(list, b),
      ),
    ];
  }

  Future<void> _softDelete(BookListNotifier list, Book b) async {
    final ok = await confirmAction(
      context,
      title: 'Удалить книгу?',
      message: '«${b.title}» будет помечена как удалённая. '
          'Её можно восстановить, включив показ удалённых.',
    );
    if (!ok) return;
    if (!mounted) return;
    await runWithFeedback(context, () => list.softDelete(b.id),
        success: 'Книга «${b.title}» удалена');
  }

  Future<void> _hardDelete(BookListNotifier list, Book b) async {
    final ok = await confirmAction(
      context,
      title: 'Удалить навсегда?',
      message: '«${b.title}» будет стёрта без возможности восстановления.',
      confirmLabel: 'Удалить навсегда',
    );
    if (!ok) return;
    if (!mounted) return;
    await runWithFeedback(context, () => list.hardDelete(b.id),
        success: 'Книга «${b.title}» удалена навсегда');
  }

  Future<void> _deleteSelected(BookListNotifier list) async {
    final count = list.selected.length;
    final ok = await confirmAction(
      context,
      title: 'Удалить выбранные книги?',
      message: 'Выбрано записей: $count. Они будут помечены как удалённые; '
          'уже удалённые записи пропускаются.',
      confirmLabel: 'Удалить ($count)',
    );
    if (!ok) return;
    if (!mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      final r = await list.deleteSelected();
      messenger.showSnackBar(SnackBar(content: Text('Удалено книг: ${r.deleted}')));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Ошибка: $e')));
    }
  }
}
