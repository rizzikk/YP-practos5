import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../auth/auth_notifier.dart';
import '../auth/permissions.dart';
import '../forms/validators.dart' show formatDate;
import '../models/loan.dart';
import '../router/locations.dart';
import '../state/load_status.dart';
import '../state/loans_list_notifier.dart';
import '../widgets/dialogs.dart';
import '../widgets/entity_table.dart';
import '../widgets/pagination_bar.dart';
import '../widgets/state_views.dart';

/// Подпись и цвет состояния выдачи.
class LoanStatusChip extends StatelessWidget {
  const LoanStatusChip({super.key, required this.status});
  final String status;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final (label, bg, fg) = switch (status) {
      'overdue' => ('просрочена', scheme.errorContainer, scheme.onErrorContainer),
      'returned' => (
          'возвращена',
          scheme.surfaceContainerHighest,
          scheme.onSurfaceVariant
        ),
      _ => ('на руках', scheme.secondaryContainer, scheme.onSecondaryContainer),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration:
          BoxDecoration(color: bg, borderRadius: BorderRadius.circular(6)),
      child: Text(label,
          style: Theme.of(context).textTheme.labelMedium?.copyWith(color: fg)),
    );
  }
}

String _date(DateTime? d) => d == null ? '—' : formatDate(d.toLocal());

/// Продление с понятным ответом: успех — полосой внизу, отказ сервера
/// (например, 403) — отдельным окном.
Future<void> _extend(BuildContext context, LoansListNotifier list, Loan loan) async {
  final messenger = ScaffoldMessenger.of(context);
  try {
    final updated = await list.extend(loan);
    messenger.showSnackBar(SnackBar(
        content: Text('Срок по «${loan.bookTitle}» продлён до '
            '${_date(updated.dueAt)}')));
  } catch (e) {
    if (context.mounted) {
      await showApiError(context, e,
          prefix: 'Продлить не удалось', messenger: messenger);
    }
  }
}

// ------------------------------------------------------------ читатель

/// «Мои выдачи» — экран читателя. Сервер по токену сам возвращает только
/// выдачи этого читателя.
class MyLoansScreen extends StatefulWidget {
  const MyLoansScreen({super.key});

  @override
  State<MyLoansScreen> createState() => _MyLoansScreenState();
}

class _MyLoansScreenState extends State<MyLoansScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final list = context.read<LoansListNotifier>();
      if (list.query.readerId != null) list.load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final list = context.watch<LoansListNotifier>();
    final auth = context.watch<AuthNotifier>();
    final canExtend = auth.has(Permission.extendOwnLoan);
    final items = list.result.items;
    if (list.query.readerId == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Мои выдачи')),
        body: const MessageView(
          icon: Icons.badge_outlined,
          title: 'Читательский билет не оформлен',
          message: 'Учётная запись ещё не связана с читателем библиотеки. '
              'Билет оформляет библиотекарь; после этого здесь появятся '
              'выданные вам книги.',
        ),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text('Мои выдачи'),
        actions: [
          IconButton(
            tooltip: 'Обновить',
            icon: const Icon(Icons.refresh),
            onPressed: list.load,
          ),
        ],
      ),
      body: ListStateView(
        status: list.status,
        error: list.error,
        hasData: items.isNotEmpty,
        emptyTitle: 'Выдач нет',
        emptyMessage: 'Сейчас у вас нет книг из библиотеки.',
        onRetry: list.load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            for (final loan in items)
              Card(
                child: ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  leading: const Icon(Icons.menu_book, size: 32),
                  title: Wrap(
                    spacing: 8,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      Text(loan.bookTitle),
                      LoanStatusChip(status: loan.status),
                    ],
                  ),
                  subtitle: Text('Выдана ${_date(loan.issuedAt)} · '
                      '${loan.returnedAt == null ? 'вернуть до ${_date(loan.dueAt)}' : 'возвращена ${_date(loan.returnedAt)}'}'),
                  onTap: () => context.go(bookLocation(loan.bookId)),
                  trailing: canExtend && loan.returnedAt == null
                      ? FilledButton.tonalIcon(
                          onPressed: list.isBusy(loan.id)
                              ? null
                              : () => _extend(context, list, loan),
                          icon: const Icon(Icons.update),
                          label: const Text('Продлить на 14 дней'),
                        )
                      : null,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// --------------------------------------------------------- библиотекарь

/// «Выдачи» — рабочее место библиотекаря: все выдачи, продление, закрытие.
class LoansScreen extends StatefulWidget {
  const LoansScreen({super.key});

  @override
  State<LoansScreen> createState() => _LoansScreenState();
}

class _LoansScreenState extends State<LoansScreen> {
  /// Значение «all» означает «без фильтра».
  static const _filters = <String, String>{
    'all': 'Все',
    'active': 'На руках',
    'overdue': 'Просрочены',
    'returned': 'Возвращены',
  };

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<LoansListNotifier>().load();
    });
  }

  Future<void> _close(LoansListNotifier list, Loan loan) async {
    final ok = await confirmAction(
      context,
      title: 'Закрыть выдачу?',
      message: '«${loan.bookTitle}» — ${loan.readerName}. Книга вернётся '
          'в фонд и станет доступна для выдачи.',
      confirmLabel: 'Закрыть выдачу',
      destructive: false,
    );
    if (!ok || !mounted) return;
    await runWithFeedback(context, () => list.close(loan),
        success: 'Выдача закрыта: «${loan.bookTitle}»');
  }

  @override
  Widget build(BuildContext context) {
    final list = context.watch<LoansListNotifier>();
    final result = list.result;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Выдачи'),
        actions: [
          IconButton(
            tooltip: 'Обновить',
            icon: const Icon(Icons.refresh),
            onPressed: list.load,
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Wrap(
              spacing: 16,
              runSpacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                SegmentedButton<String>(
                  segments: [
                    for (final e in _filters.entries)
                      ButtonSegment(value: e.key, label: Text(e.value)),
                  ],
                  selected: {list.query.status ?? 'all'},
                  onSelectionChanged: (v) => list
                      .setStatusFilter(v.first == 'all' ? null : v.first),
                ),
                Text(
                  'Новая выдача оформляется в карточке книги '
                  'кнопкой «Выдать читателю».',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          Expanded(
            child: ListStateView(
              status: list.status,
              error: list.error,
              hasData: result.items.isNotEmpty,
              emptyTitle: 'Выдач нет',
              emptyMessage: 'Под выбранное состояние не подходит ни одна выдача.',
              onRetry: list.load,
              child: EntityTable<Loan>(
                items: result.items,
                idOf: (l) => l.id,
                isInactive: (l) => l.returnedAt != null,
                onOpen: (l) => context.go(bookLocation(l.bookId)),
                columns: [
                  TableColumnSpec(label: 'Книга', build: (l) => Text(l.bookTitle)),
                  TableColumnSpec(
                      label: 'Читатель', build: (l) => Text(l.readerName)),
                  TableColumnSpec(
                      label: 'Выдана', build: (l) => Text(_date(l.issuedAt))),
                  TableColumnSpec(
                      label: 'Вернуть до', build: (l) => Text(_date(l.dueAt))),
                  TableColumnSpec(
                      label: 'Состояние',
                      build: (l) => LoanStatusChip(status: l.status)),
                ],
                actions: (l) => l.returnedAt != null
                    ? const []
                    : [
                        IconButton(
                          tooltip: 'Продлить на 14 дней',
                          icon: const Icon(Icons.update),
                          onPressed: list.isBusy(l.id)
                              ? null
                              : () => _extend(context, list, l),
                        ),
                        IconButton(
                          tooltip: 'Закрыть выдачу',
                          icon: const Icon(Icons.assignment_return_outlined),
                          onPressed:
                              list.isBusy(l.id) ? null : () => _close(list, l),
                        ),
                      ],
              ),
            ),
          ),
          if (list.status != LoadStatus.error && result.total > 0)
            PaginationBar(
              result: result,
              size: result.size,
              onPage: list.setPage,
              onSize: list.setSize,
            ),
        ],
      ),
    );
  }
}
