import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../auth/auth_notifier.dart';
import '../router/locations.dart';
import '../router/sections.dart';
import '../state/author_list_notifier.dart';
import '../state/book_list_notifier.dart';
import '../state/list_notifiers.dart';
import '../widgets/dialogs.dart';

/// Общая оболочка: шапка с пользователем и кнопкой выхода, боковое меню
/// на широком окне и нижнее — на узком. Меню строится по правам роли.
class AppShell extends StatelessWidget {
  final String location;
  final Widget child;

  const AppShell({super.key, required this.location, required this.child});

  /// Возврат в раздел списка восстанавливает его последние условия отбора.
  static String targetOf(BuildContext context, AppSection section) =>
      switch (section.path) {
        booksPath => booksLocation(context.read<BookListNotifier>().query),
        authorsPath =>
          authorsLocation(context.read<AuthorListNotifier>().query),
        genresPath =>
          listLocation(genresPath, context.read<GenreListNotifier>().query),
        publishersPath => listLocation(
            publishersPath, context.read<PublisherListNotifier>().query),
        readersPath =>
          listLocation(readersPath, context.read<ReaderListNotifier>().query),
        _ => section.path,
      };

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthNotifier>();
    final sections = sectionsFor(auth);
    final current = sectionOf(location, sections);
    final index = current == null ? null : sections.indexOf(current);
    final narrow = MediaQuery.sizeOf(context).width < 600;

    void select(int i) => context.go(targetOf(context, sections[i]));

    if (narrow) {
      // На узком экране в нижней панели помещается пять пунктов;
      // остальное — под «Ещё».
      final main = sections.length > 5 ? sections.sublist(0, 4) : sections;
      final more = sections.length > 5 ? sections.sublist(4) : <AppSection>[];
      final selected = index == null
          ? 0
          : index < main.length
              ? index
              : main.length;
      return Scaffold(
        body: Column(
          children: [
            const UserBar(compact: true),
            const Divider(height: 1),
            Expanded(child: child),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selected,
          onDestinationSelected: (i) {
            if (i < main.length) {
              select(i);
            } else {
              _showMore(context, more);
            }
          },
          labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
          destinations: [
            for (final s in main)
              NavigationDestination(icon: Icon(s.icon), label: s.label),
            if (more.isNotEmpty)
              const NavigationDestination(
                  icon: Icon(Icons.more_horiz), label: 'Ещё'),
          ],
        ),
      );
    }

    return Scaffold(
      body: Column(
        children: [
          const UserBar(),
          const Divider(height: 1),
          Expanded(
            child: Row(
              children: [
                NavigationRail(
                  selectedIndex: index,
                  onDestinationSelected: select,
                  labelType: NavigationRailLabelType.all,
                  destinations: [
                    for (final s in sections)
                      NavigationRailDestination(
                          icon: Icon(s.icon), label: Text(s.label)),
                  ],
                ),
                const VerticalDivider(width: 1),
                Expanded(child: child),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showMore(BuildContext context, List<AppSection> more) {
    showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (final s in more)
              ListTile(
                leading: Icon(s.icon),
                title: Text(s.label),
                subtitle: Text(s.description),
                onTap: () {
                  Navigator.of(sheetContext).pop();
                  context.go(targetOf(context, s));
                },
              ),
          ],
        ),
      ),
    );
  }
}

/// Шапка: название, роль и имя вошедшего пользователя, кнопка выхода.
class UserBar extends StatelessWidget {
  const UserBar({super.key, this.compact = false});
  final bool compact;

  Future<void> _logout(BuildContext context) async {
    final auth = context.read<AuthNotifier>();
    final ok = await confirmAction(
      context,
      title: 'Выйти из системы?',
      message: 'Токены будут удалены из браузера, для продолжения работы '
          'понадобится войти снова.',
      confirmLabel: 'Выйти',
      destructive: false,
    );
    if (ok) await auth.logout();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthNotifier>();
    final user = auth.user;
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return Material(
      color: scheme.surfaceContainer,
      child: SizedBox(
        height: 52,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Icon(Icons.local_library, color: scheme.primary),
              const SizedBox(width: 10),
              if (!compact)
                Text('Библиотека', style: theme.textTheme.titleMedium),
              const Spacer(),
              if (user != null) ...[
                if (!compact) ...[
                  Chip(
                    avatar: const Icon(Icons.verified_user_outlined, size: 18),
                    label: Text(user.role.label),
                    visualDensity: VisualDensity.compact,
                  ),
                  const SizedBox(width: 12),
                ],
                CircleAvatar(
                  radius: 15,
                  backgroundColor: scheme.primaryContainer,
                  child: Text(
                    user.fullName.isEmpty ? '?' : user.fullName.characters.first,
                    style: TextStyle(color: scheme.onPrimaryContainer),
                  ),
                ),
                const SizedBox(width: 8),
                // Ограничение ширины, а не Flexible: иначе Spacer делил бы
                // свободное место с именем и блок уезжал бы к середине.
                ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: compact ? 140 : 280),
                  child: Text(
                    user.fullName,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleSmall,
                  ),
                ),
                const SizedBox(width: 8),
                compact
                    ? IconButton(
                        tooltip: 'Выйти',
                        icon: const Icon(Icons.logout),
                        onPressed: () => _logout(context),
                      )
                    : TextButton.icon(
                        onPressed: () => _logout(context),
                        icon: const Icon(Icons.logout),
                        label: const Text('Выйти'),
                      ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
